/*
 * NCSA Horizon Image Browser
 * Project Horizon
 * National Center for Supercomputing Applications
 * University of Illinois at Urbana-Champaign
 * 605 E. Springfield, Champaign IL 61820
 * horizon@ncsa.uiuc.edu
 *
 * Copyright (C) 1996, Board of Trustees of the University of Illinois
 *
 * NCSA Horizon software, both binary and source (hereafter, Software) is
 * copyrighted by The Board of Trustees of the University of Illinois
 * (UI), and ownership remains with the UI.
 *
 * You should have received a full statement of copyright and
 * conditions for use with this package; if not, a copy may be
 * obtained from the above address.  Please see this statement
 * for more details.
 *
 */
package ncsa.horizon.coordinates.coordpos;

import java.util.*;
import ncsa.horizon.coordinates.*;
import ncsa.horizon.util.Metadata;
import ncsa.horizon.util.OneWayWriteProtection;
import ncsa.horizon.util.WriteProtectionException;
import ncsa.horizon.util.MetadataTypeException;
import ncsa.horizon.coordinates.coordaxispos.GenericCoordAxisPos;
import ncsa.horizon.coordinates.coordaxispos.HHMMSSCoordAxisPos;
import ncsa.horizon.coordinates.coordaxispos.DDMMSSCoordAxisPos;

public class GenCoordPos extends CoordPos {

    private int naxes;
    protected String[] labels;
    private double[] pos;
    private CoordAxisPos[] posPrinter;
    private static GenericCoordAxisPos defPosPrinter = 
                                                new GenericCoordAxisPos();
    protected Metadata cmdata;
    protected boolean metadata_readonly = false;

    /**
     * create a GenCoordPos with a particular value
     * @param in coordinate position as an array of doubles; the value
     *           for the first axis should appear at the index given by
     *           firstaxis.  
     * @param mdata the set of metadata that describes the Coordinate system
     *              Note that expected metadata keys of the wrong type are 
     *              ignored (see above).
     * @param firstaxis the default index to be used for the first axis as 
     *                  well as the index of the first axis used by in
     * @param prot_metadata whether the metadata can be updated using 
     *                      addMetadata().  
     * @exception ArrayIndexOutOfBoundsException if the metadatum "naxes" 
     *               (the number of axes) is less than or equal to zero.
     */
    public GenCoordPos(double[] in, Metadata mdata, int firstaxis, 
		       boolean prot_metadata) 
	throws ArrayIndexOutOfBoundsException
    {
	init(in, mdata, firstaxis, prot_metadata);
    }

    private void init(double[] in, Metadata mdata, int firstaxis, 
		      boolean prot_metadata) {
	String sval, saval[], types[];
	Integer ival;
	CoordAxisPos[] capval;
	int i;

	// set the axis numbering convention
	//
	firstAxisIndex = firstaxis;

	// clone the input metadata; 
	// 
	cmdata = cloneMetadata(mdata);

	// check to be sure we have all the metadata we need.  Keep 
        // some extracted references to important information 
	// for even faster access (than from the hashtable cmdata)
	//
	// check for the number of axes: need at least 1
	//
	try {
	    ival = (Integer) cmdata.getMetadatum("naxes");
	} catch (ClassCastException e) {
	    ival = null;
	}
	if (ival == null) 
	    naxes = 0;
	else 
	    naxes = ival.intValue();
	if (naxes < 1) throw new 
	    ArrayIndexOutOfBoundsException("Coordinate property naxes=" + 
					   naxes + " < 1");

	// Axis labels; need one for each axis (use "axtypes" as default
	// labels if necessary).
	//
	setLabels(null);

	// Axis value formatters; need one for each axis
	//
	setFormats(null);

	// now set the position
	pos = new double[naxes];
	initPos(in);

	// set the write protection on the Metadata object
	metadata_readonly = prot_metadata;
    }

    /**
     * create a GenCoordPos with a particular value
     * @param in coordinate position as an array of doubles
     * @param mdata the set of metadata that describes the Coordinate system
     *              Note that expected metadata keys of the wrong type are 
     *              ignored (see above).
     * @param firstaxis the default index to be used for the first axis as 
     *                  well as the index of the first axis used by in
     * @exception ArrayIndexOutOfBoundsException if the metadatum "naxes" 
     *               (the number of axes) is less than or equal to zero.
     */
    public GenCoordPos(double[] in, Metadata mdata, int firstaxis) 
	throws ArrayIndexOutOfBoundsException 
    {
	init(in, mdata, firstaxis, true);
    }

    /**
     * create a GenCoordPos with a particular value
     * @param in coordinate position as an array of doubles (with the value
     *           for the first axis at index 0)
     * @param mdata the set of metadata that describes the Coordinate system
     *              Note that expected metadata keys of the wrong type are 
     *              ignored (see above).
     * @exception ArrayIndexOutOfBoundsException if the metadatum "naxes" 
     *               (the number of axes) is less than or equal to zero.
     */
    public GenCoordPos(double[] in, Metadata mdata) 
	throws ArrayIndexOutOfBoundsException 
    {
	init(in, mdata, 0, true);
    }

    /**
     * create a GenCoordPos with a particular value.  This version of the 
     * constructor is provided so that one does not have to completely
     * specify a metadatum list.  Input values for the first axis should
     * appear in the input arrays at index 0.
     * @param nax the number of axes in this coordinate system
     * @param name[] an array of the axis names; these are used both as 
     *               labels and type names.
     * @param in[]   coordinate position as an array of doubles
     * @param formatter[] an array of CoordAxisPos objects to use when 
     *               formatting the position into a string.
     * @param mdata  the metadatum list; if no other metadata need 
     *               specifying besides the above values, pass null for 
     *               this argument.
     */
    public GenCoordPos(int nax, String[] name, double[] in, 
		       CoordAxisPos[] formatter, Metadata mdata) 
	throws ArrayIndexOutOfBoundsException 
    {
	if (nax <= 0) throw new 
	    ArrayIndexOutOfBoundsException("Coordinate property naxes=" + 
					    nax + " < 1");
	if (mdata == null) mdata = new Metadata();

	mdata.put(new String("naxes"), new Integer(nax));
	mdata.put(new String("axtypes"), name);
	mdata.put(new String("axlabels"), name);
	if (formatter != null) mdata.put(new String("axformats"), formatter);

	init(in, mdata, 0, true);
    }
	    
    private void initPos(double[] in) {
	int i;

	// initialize the position from input
	if (in != null) {
	    for(i=0; i < naxes && i + firstAxisIndex < in.length; i++) {
		pos[i] = in[i + firstAxisIndex]; 
	    }
	} else { i=0; }

	// cover any uninitialized position values
	for(; i < naxes; i++) {
	    pos[i] = 0;
	}
    }

    /** 
     * set the index of the first axis 
     * @param firstaxis default index of the first axis
     * @exception WriteProtectionException if writeProtect() was called
     */
    public void setFirstAxisIndex(int firstaxis) 
	throws WriteProtectionException 
    {

	// firstAxisIndex is not officially metatdata but is still 
	// protected like metadata
 	if (metadata_readonly) throw new 
 	    WriteProtectionException("CoordPos", "firstIndexAxis is locked");

	firstAxisIndex = firstaxis;
    }

    /**
     * return the number of axes in this coordinate system
     */
    public int getNaxes() { return naxes; } 

    /**
     * return the currently set label for an axis
     * @param axis the axis of interest; axes are numbered beginning with 0.
     */
    public String axisLabel(int axis) throws ArrayIndexOutOfBoundsException {
	return new String(labels[axis-firstAxisIndex]);
    }

    /**
     * return the currently set labels for the axes
     */
    public String[] axisLabels(int firstaxis) 
	throws ArrayIndexOutOfBoundsException
    {
	if (firstaxis < 0) throw new 
	    ArrayIndexOutOfBoundsException("firstaxis < 0: " + firstaxis);

	String[] out = new String[labels.length + firstaxis];
	System.arraycopy(labels, 0, out, firstaxis, labels.length);
	return out;
    }

    /**
     * set the label for an axis
     * @param lab label to use
     * @param axis the axis of interest; axes are numbered beginning with 0.
     */
    public void setAxisLabel(String lab, int axis) 
	throws ArrayIndexOutOfBoundsException 
    {
	if (lab == null) return;
	labels[axis-firstAxisIndex] = lab;
    }

    /**
     * set the labels for all the axes
     * @param lab label to use
     * @param firstaxis the index of the label for the first axis in lab
     * @exception ArrayIndexOutOfBoundsException if firstaxis < 0;
     */
    public void setAxisLabels(String[] lab, int firstaxis) 
	throws ArrayIndexOutOfBoundsException
    {
	int i;
	if (firstaxis < 0) throw new 
	    ArrayIndexOutOfBoundsException("firstaxis < 0: " + firstaxis);


	if (lab == null) return;
	for(i=0; i < naxes && i < lab.length; i++) {
		labels[i] = lab[i];
	}
    }

    /**
     * set the labels for all the axes
     * @param lab array of labels to use; the label for the first axis should
     *            appear at the index equal to firstAxisIndex
     */
    public void setAxisLabels(String[] labs) {
	if (firstAxisIndex < 0)
	    setAxisLabels(labs, 0);
	else
	    setAxisLabels(labs, firstAxisIndex);
    }

    /**
     * return a double containing the position's projection along
     * an axis
     * @param axis the axis of interest; axes are numbered beginning with 0.
     */
    public double value(int axis) throws ArrayIndexOutOfBoundsException {
	return pos[axis-firstAxisIndex];
    }

    /**
     * set the position's projection along an axis to a value
     * @param axis the axis of interest; axes are numbered beginning with 0.
     * @param newval the new value
     * @return the old value
     */
    public void setValue(int axis, double newval) 
	throws ArrayIndexOutOfBoundsException 
    {
	    pos[axis-firstAxisIndex] = newval;
    }

    /**
     * return an array of doubles representing the position along each
     * axis
     */
    public double[] values(int firstaxis) {
	double[] out = new double[pos.length];
	System.arraycopy(pos, 0, out, firstaxis, pos.length);
	return out;
    }

    /**
     * set the position along all axes with the values given in the input
     * array, returning the old values;
     */
    public void setValues(double[] newpos, int firstaxis) {
	int i;
	double[] tmp;

	if (newpos == null) return;

	for(i=0; i + firstaxis < newpos.length && i < pos.length; i++) {
	    pos[i] = newpos[i+firstaxis];
	}
    }

    /**
     * return a formatted string containing the position's projection along
     * an axis
     * @param axis the axis of interest; axes are numbered beginning with 0.
     */
    public String valStr(int axis) throws ArrayIndexOutOfBoundsException {
	return 
	    posPrinter[axis-firstAxisIndex].valStr(pos[axis-firstAxisIndex]);
    }

    /**
     * return an array of formatted strings containing the position's 
     * projection along each axis
     * @param firstaxis the index at which the string for the first axis
     *                  should appear in the output array
     */
    public String[] valStrs(int firstaxis) 
	throws ArrayIndexOutOfBoundsException 
    {
	String[] out = new String[naxes+firstaxis];
	for(int i=0; i < naxes; i++) 
	    out[i+firstaxis] = posPrinter[i].valStr(pos[i]);

	return out;
    }

    /**
     * return a MetaData object that identifies this coordinate 
     * system.  
     */
    public Metadata getMetadata() {
	return cloneMetadata(cmdata);
    }

    /**
     * add or overwrite metadata for this object; metadata not found in 
     * the input object remain unaltered.
     * @exception WriteProtectionException if a call to writeProtect() has
     *            been called.
     * @exception MetadataTypeException if an input metadatum with an 
     *            expected key name is of an unexpected type.
     */
    public synchronized void addMetadata(Metadata mdata) 
	throws WriteProtectionException, MetadataTypeException 
    {
 	if (metadata_readonly) throw new 
 	    WriteProtectionException("CoordPos", "Metadata object is locked");

 	Object val;
 	Metadata use = cloneMetadata(mdata);
 	for (Enumeration e = use.keys(); e.hasMoreElements();) {
 	    String key = (String) e.nextElement();
 	    val = use.getMetadatum(key);
 	    if (key.equals("naxes")) {
 		try {
 		    if ( ((Integer) val).intValue() <= 0 ) continue;
 		}
 		catch (ClassCastException ex) { 
 		    throw new MetadataTypeException("naxes", "Integer");
 		}
 	    } 
 	    else if (key.equals("axlabels") || key.equals("axformats") ) {
 		continue;
 	    }

 	    cmdata.put(key, val);
 	}

	String[] tmp;
 	if ((tmp = getStringArrayMetadatum("axlabels",use)) != null) 
 	    setLabels(tmp);
	CoordAxisPos[] tmpcap;
  	if ((tmpcap = getFormatsMetadatum(use)) != null) 
  	    setFormats(tmpcap);
	return;
    }

    private static String[] getStringArrayMetadatum(String key, Metadata mdata) 
    {
	try {
	    return (String[]) mdata.getMetadatum(key);
	}
	catch (ClassCastException e) { 
	    return null;
	}
    }

    private static CoordAxisPos[] getFormatsMetadatum(Metadata mdata) {
	try {
	    return (CoordAxisPos[]) mdata.getMetadatum("axformats");
	}
	catch (ClassCastException e) { 
	    return null;
	}
    }	

    private static Integer getNaxesMetadata(Metadata mdata) {
	try {
	    return (Integer) mdata.getMetadatum("naxes");
	}
	catch (ClassCastException e) { 
	    return null;
	}
    }	

    private void setLabels(String[] in) {
	String[] old = getStringArrayMetadatum("axlabels", cmdata);
	if (old == null) old = new String[naxes];
	if (in == null) in = old;

	// copy non-null inputs into our array
	for(int i=0; i < naxes && i < in.length; i++) {
	    if (in[i] != null) old[i] = in[i];
	}

	// make sure our array has non-null values
	String[] types = getStringArrayMetadatum("axtypes", cmdata);
	for(int i=0; i < naxes; i++) {
	    if (old[i] == null) { 
		if (types != null && types.length > i) 
		    old[i] = types[i];
		else 
		    old[i] = "pixels";
	    }
	}

	// set our fast-acces copy of reference
	if (labels == null) labels = old;
    }
	    
    private void setTypes(String[] in) {
	String[] old = getStringArrayMetadatum("axtypes", cmdata);
	if (old == null) old = new String[naxes];
	if (in == null) in = old;

	// copy non-null inputs into our array
	for(int i=0; i < naxes && i < in.length; i++) {
	    if (in[i] != null) old[i] = in[i];
	}
    }
	    
    private void setFormats(CoordAxisPos[] in) {
	CoordAxisPos[] old = getFormatsMetadatum(cmdata);
	if (old == null) {
	    old = new CoordAxisPos[naxes];
	    cmdata.put(new String("axformats"), old);
	}
	if (in == null) in = old;

	// copy non-null inputs into our array
	for(int i=0; i < naxes && i < in.length; i++) {
	    if (in[i] != null) old[i] = in[i];
	}

	// make sure our array has non-null values
	for(int i=0; i < naxes; i++) {
	    if (old[i] == null) { 
		old[i] = defPosPrinter;
	    }
	}

	// set our fast-acces copy of reference
	if (posPrinter == null) posPrinter = old;
    }
	    
    /**
     * clone a Metadata object making "deep" copies of those metadata most
     * relevent to this object (and thus in need of protection), namely:
     * "naxes", "axnames", "axlabels", & "axformats".
     */
    protected static Metadata cloneMetadata(Metadata mdata) {
	Metadata out = (Metadata) mdata.clone();
	String[] instr, outstr;
	CoordAxisPos[] incap, outcap;
	Integer n;
	int i;

	// naxes
	try {                                      // get the axis labels
	    n = (Integer) out.getMetadatum("naxes");
	} catch (ClassCastException e) {
	    n = null;
	}
	if (n != null) {
	    n = new Integer(n.intValue());
	    out.put(new String("naxes"), n);
	}

	// axis types
	try {                                      // get the axis types
	    instr = (String[]) out.getMetadatum("axtypes");
	} catch (ClassCastException e) {
	    instr = null;
	}
	if (instr != null) {
	    outstr = new String[instr.length];
	    System.arraycopy(instr, 0, outstr, 0, instr.length);
	    out.put(new String("axtypes"), outstr);
	}
	
	// axis labels
	try {                                      // get the axis labels
	    instr = (String[]) out.getMetadatum("axlabels");
	} catch (ClassCastException e) {
	    instr = null;
	}
	if (instr != null) {
	    outstr = new String[instr.length];
	    System.arraycopy(instr, 0, outstr, 0, instr.length);
	    out.put(new String("axlabels"), outstr);
	}

	// axis formatters
	try {                                      // get the axis labels
	    incap = (CoordAxisPos[]) out.getMetadatum("axformats");
	} catch (ClassCastException e) {
	    incap = null;
	}
	if (incap != null) {
	    outcap = new CoordAxisPos[incap.length];
	    System.arraycopy(incap, 0, outcap, 0, incap.length);
	    out.put(new String("axformats"), outcap);
	}

	return out;
    }	

    /**
     * clone this object
     */
    public Object clone() {
	GenCoordPos out;

	out = new GenCoordPos(pos, cmdata, 0);
	out.firstAxisIndex = firstAxisIndex;
	out.metadata_readonly = false;

	return out;
    }

    /** 
     * turn on write protection of the metadata for this CoordPos 
     * object (i.e. do not allow calls to addMetadata())
     * @return whether the write protection was changed
     */
    public boolean writeProtect() {
	boolean old = metadata_readonly;
	metadata_readonly = true;
	return (metadata_readonly != old);
    }

    /**
     * return whether write protection of the metadata for this 
     * CoordPos object is on (i.e. whether calls to addMetadata()
     * are allowed).
     */
    public boolean isWriteProtected() {
	return metadata_readonly;
    }

    public static void main(String args[]) {
	int i;
	String sp;
	String names[] = { "RA", "Dec", "Velo" };
	double mine[] = { 45.7, 23.0, 18.0 };
	CoordAxisPos frmtrs[] = { new HHMMSSCoordAxisPos(),
				  new DDMMSSCoordAxisPos(),
				  new GenericCoordAxisPos() };
	Metadata mdata = new Metadata();
	mdata.put(new String("space"), new String("Celestial-Velocity"));

	CoordPos mycp = new GenCoordPos(3, names, mine, frmtrs, mdata);
	sp = (String) mycp.getMetadata().getMetadatum(new String("space"), 
			    	                      new String("my"));
	System.out.println("My position in " + sp + " space...");
	try {
	    for (i=0; i < mycp.getNaxes(); i++) {
		System.out.println("  " + mycp.axisLabel(i) + 
				   ": " + mycp.valStr(i)      );
	    }
	} 
 	catch (ArrayIndexOutOfBoundsException ex) { 
 	    throw new InternalError("Logic Error: " + ex.toString());
 	}
	if (args.length <= 0) System.exit(0);

	double[] yours = new double[args.length];
	for(i=0; i < args.length; i++) {
	    yours[i] = new Double(args[i]).doubleValue();
	}

	CoordPos yourcp = (CoordPos) mycp.clone();
	yourcp.setValues(yours, 0);

	System.out.println("Your position " + sp + " space...");
//	try {
	    for (i=0; i < yourcp.getNaxes(); i++) {
		System.out.println("  " + yourcp.axisLabel(i) + 
				   ": " + yourcp.valStr(i)      );
	    }
// 	} catch (ArrayIndexOutOfBoundsException ex) { 
// 	    throw new InternalError("Logic Error: " + ex.toString());
// 	}

    }

};
