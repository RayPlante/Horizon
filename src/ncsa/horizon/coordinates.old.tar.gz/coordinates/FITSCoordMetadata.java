/*
 * NCSA Horizon Image Browser
 * Project Horizon
 * National Center for Supercomputing Applications
 * University of Illinois at Urbana-Champaign
 * 605 E. Springfield, Champaign IL 61820
 * horizon@ncsa.uiuc.edu
 *
 * Copyright (C) 1996, Board of Trustees of the University of Illinois
 *
 * NCSA Horizon software, both binary and source (hereafter, Software) is
 * copyrighted by The Board of Trustees of the University of Illinois
 * (UI), and ownership remains with the UI.
 *
 * You should have received a full statement of copyright and
 * conditions for use with this package; if not, a copy may be
 * obtained from the above address.  Please see this statement
 * for more details.
 *
 */
package ncsa.horizon.coordinates;

import java.util.*;
import ncsa.horizon.util.Metadata;
import ncsa.horizon.coordinates.coordaxispos.GenericCoordAxisPos;
import ncsa.horizon.coordinates.coordaxispos.HHMMSSCoordAxisPos;
import ncsa.horizon.coordinates.coordaxispos.DDMMSSCoordAxisPos;

/**
 * a Metadata object with extra help for Coordinate objects
 */
public class FITSCoordMetadata extends CoordMetadata {

    /**
     * Number of axes must be set during construction; thus this 
     * method is hidden from user
     */
    public FITSCoordMetadata() {
	super();
    }

    /**
     * Creates an metadatum list for a coordinate system with naxes axes
     * @param naxes the number of axes in the coordinate system
     * @param defaults the defaults (can be null)
     */
    public FITSCoordMetadata(int naxes, Metadata defaults) 
	throws ArrayIndexOutOfBoundsException
    {
	super(naxes, defaults);
    }

    /**
     * Creates an empty metadatum list with specified defaults.
     * @param defaults the defaults
     */
    public FITSCoordMetadata(int naxes) 
	throws ArrayIndexOutOfBoundsException
    {
	super(naxes);
    }

    /**
     * Creates an empty metadatum list with specified defaults.
     * @param defaults the defaults
     */
    public FITSCoordMetadata(Metadata defaults) 
	throws ArrayIndexOutOfBoundsException
    {
	super(defaults);
    }

    public int getNAXIS() { return super.getNaxes(); }
    public void setNAXIS(int nax) { super.setNaxes(nax); }
    public void setCTYPE(int axis, String in) { setAxname(axis, in); }
    public void setCRVAL(int axis, double in) { setRefposition(axis, in); }
    public void setCRPIX(int axis, double in) { setRefvoxel(axis, in); }
    public void setCDELT(int axis, double in) { setVoxelsize(axis, in); }

    public static void main(String args[]) {

	FITSCoordMetadata cmd = new FITSCoordMetadata();
	CoordAxisPos deffmt = new GenericCoordAxisPos();
	double[] voxsz = { 1.0, 1.0, 1.0 };
	String key;
	Object val;

	cmd.setNAXIS(2);
	cmd.setName("Inner Space");
	cmd.setCTYPE(1, "Dharma");
	cmd.setCTYPE(0, "Karma");
	cmd.setAxlabel(0, "Blinky");
	cmd.setAxlabel(2, "Nod");
	cmd.setAxformat(1, deffmt);
	cmd.setCRPIX(2, 8.2);
	cmd.setCRPIX(1, 5.0);
	cmd.setCRPIX(0, -3);
	cmd.put("voxelsize", voxsz);
	cmd.put("projection", new String("flat"));
	cmd.setCRVAL(1, 42);

	StringBuffer out;
	int l;
	for(Enumeration e = cmd.keys(); e.hasMoreElements();) {
	    key = (String) e.nextElement();
	    val = cmd.getMetadatum(key);
	    out = new StringBuffer(key + ": ");
	    l = out.length();
	    if (val instanceof String[]) {
		String[] v = ((String[]) val);
		out.append(v[0]);
		for(int i=1; i < v.length; i++) {
		    out.append("\n");
		    for(int j=0; j < l; j++) out.append(" ");
		    out.append(v[i]);
		}
	    }
	    else if (val instanceof double[]) {
		double[] v = ((double[]) val);
		out.append(v[0]);
		for(int i=1; i < v.length; i++) {
		    out.append("\n");
		    for(int j=0; j < l; j++) out.append(" ");
		    out.append(v[i]);
		}
	    }
	    else if (val instanceof CoordAxisPos[]) {
		CoordAxisPos[] v = ((CoordAxisPos[]) val);
		out.append(v[0]);
		for(int i=1; i < v.length; i++) {
		    out.append("\n");
		    for(int j=0; j < l; j++) out.append(" ");
		    out.append(v[i]);
		}
	    }
	    else {
		out.append(val);
	    }
		
	    System.out.println(out);
	}

	out = new StringBuffer("changing naxes from " + cmd.getNaxes() + 
			       " to ");
	cmd.put("naxes", new Integer(3));
	out.append((Integer)cmd.getMetadatum("naxes"));
	System.out.println(out);
    }
}
