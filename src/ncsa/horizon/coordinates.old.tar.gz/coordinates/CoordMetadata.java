/*
 * NCSA Horizon Image Browser
 * Project Horizon
 * National Center for Supercomputing Applications
 * University of Illinois at Urbana-Champaign
 * 605 E. Springfield, Champaign IL 61820
 * horizon@ncsa.uiuc.edu
 *
 * Copyright (C) 1996, Board of Trustees of the University of Illinois
 *
 * NCSA Horizon software, both binary and source (hereafter, Software) is
 * copyrighted by The Board of Trustees of the University of Illinois
 * (UI), and ownership remains with the UI.
 *
 * You should have received a full statement of copyright and
 * conditions for use with this package; if not, a copy may be
 * obtained from the above address.  Please see this statement
 * for more details.
 *
 */
package ncsa.horizon.coordinates;

import java.util.*;
import ncsa.horizon.util.Metadata;
import ncsa.horizon.coordinates.coordaxispos.GenericCoordAxisPos;

/**
 * a Metadata object with extra help for Coordinate objects
 */
public class CoordMetadata extends Metadata {

    private int numaxes=1;

    private static String name        = "name";
    private static String naxes       = "naxes";
    private static String axnames     = "axnames";
    private static String axlabels    = "axlabels";
    private static String axformats   = "axformats";
    private static String refposition = "refposition";
    private static String refvoxel    = "refvoxel";
    private static String voxelsize   = "voxelsize";
    private static String refoffset   = "refoffset";

    /**
     * Number of axes must be set during construction; thus this 
     * method is hidden from user
     */
    public CoordMetadata() {
	super();
	init(1, null);
    }

    /**
     * Creates an metadatum list for a coordinate system with naxes axes
     * @param naxes the number of axes in the coordinate system
     * @param defaults the defaults (can be null)
     */
    public CoordMetadata(int naxes, Metadata defaults) 
	throws ArrayIndexOutOfBoundsException
    {
	super(defaults);
	init(naxes, defaults);
    }

    /**
     * Creates an empty metadatum list with specified defaults.
     * @param defaults the defaults
     */
    public CoordMetadata(int naxes) 
	throws ArrayIndexOutOfBoundsException
    {
	super();
        init(naxes, null);
    }

    /**
     * Creates an empty metadatum list with specified defaults.
     * @param defaults the defaults
     */
    public CoordMetadata(Metadata defaults) 
	throws ArrayIndexOutOfBoundsException
    {
	super(defaults);

	Integer nax;
	int ival;
        try {
	    nax = (Integer) defaults.getMetadatum("naxes");
	} catch (ClassCastException e) {
	    nax = null;
	}
	if (nax == null) 
	    ival = 0;
	else
	    ival = nax.intValue();

	init(ival, defaults);
    }

    private void init(int nax, Metadata defaults) {
	if (nax < 1) throw new 
	    ArrayIndexOutOfBoundsException("Coordinate Metadatum naxes=" + 
					   nax + " < 1");
	numaxes = nax;
	super.put(naxes, new Integer(nax));
    }

    public int getNaxes() {
	Integer val;

	try {
	    val = (Integer) getMetadatum(naxes);
	} catch (ClassCastException ex) {
	    val = new Integer(numaxes);
	    super.put(naxes, val);
	}
	return val.intValue();
    }

    public void setNaxes(int nax) throws ArrayIndexOutOfBoundsException {
	if (nax < 1) throw new 
	    ArrayIndexOutOfBoundsException("Requested naxes=" + nax + " < 1");
	numaxes = nax;
	super.put(naxes, new Integer(nax));
    }

    public void setName(String in) {
	super.put(name, in);
    }

    private void setStringArray(int axis, String in, String key) {
	String[] inval, useval;

	if (axis < 0) throw new 
	    ArrayIndexOutOfBoundsException("Requested axis=" + axis + " < 0");
	
	try {
	    inval = (String[]) getMetadatum(key);
	} catch (ClassCastException ex) {
	    inval = null;
	}

	if (inval == null || inval.length < Math.max(axis+1,numaxes)) {
	    useval = new String[Math.max(axis+1,numaxes)];
	    if (inval != null) 
		System.arraycopy(inval, 0, useval, 0, inval.length);
	    super.put(key, useval);
	}
	else {
	    useval = inval;
	}

	useval[axis] = in;
    }

    public void setAxlabel(int axis, String in) {
	setStringArray(axis, in, axlabels);
    }

    public void setAxname(int axis, String in) {
	setStringArray(axis, in, axnames);
    }

    private void setdoubleArray(int axis, double in, String key) {
	double[] inval, useval;

	if (axis < 0) throw new 
	    ArrayIndexOutOfBoundsException("Requested axis=" + axis + " < 0");
	
	try {
	    inval = (double[]) getMetadatum(key);
	} catch (ClassCastException ex) {
	    inval = null;
	}

	if (inval == null || inval.length < Math.max(axis+1,numaxes)) {
	    useval = new double[Math.max(axis+1,numaxes)];
	    if (inval != null) 
		System.arraycopy(inval, 0, useval, 0, inval.length);
	    super.put(key, useval);
	}
	else {
	    useval = inval;
	}

	useval[axis] = in;
    }

    public void setRefposition(int axis, double in) {
	setdoubleArray(axis, in, refposition);
    }

    public void setRefvoxel(int axis, double in) {
	setdoubleArray(axis, in, refvoxel);
    }

    public void setRefOffset(int axis, double in) {
	setdoubleArray(axis, in, refoffset);
    }

    public void setVoxelsize(int axis, double in) {
	setdoubleArray(axis, in, voxelsize);
    }

    public void setAxformat(int axis, CoordAxisPos in) {
	CoordAxisPos[] inval, useval;

	if (axis < 0) throw new 
	    ArrayIndexOutOfBoundsException("Requested axis=" + axis + " < 0");
	
	try {
	    inval = (CoordAxisPos[]) getMetadatum(axformats);
	} catch (ClassCastException ex) {
	    inval = null;
	}

	if (inval == null || inval.length < Math.max(axis+1,numaxes)) {
	    useval = new CoordAxisPos[Math.max(axis+1,numaxes)];
	    if (inval != null) 
		System.arraycopy(inval, 0, useval, 0, inval.length);
	    super.put(axformats, useval);
	}
	else {
	    useval = inval;
	}

	useval[axis] = in;
    }

    public Object put(Object inkey, Object val) {
	if (! (inkey instanceof String)) return null;
	String key = (String) inkey;

	boolean special = true;
	Object old = getMetadatum(key);
	try {
	    if (key.equals(naxes)) 
		setNaxes( ((Integer) val).intValue() );
	    else if (key.equals(name)) 
		setName( (String) val );
	    else if (key.equals(axnames) || key.equals(axlabels))
		super.put(key, (String[]) val);
	    else if (key.equals(refposition) || key.equals(refvoxel) ||
		     key.equals(voxelsize))
		super.put(key, (double[]) val);
	    else if (key.equals(axformats))
		super.put(key, (CoordAxisPos[]) val);
	    else
		special = false;
	}
	catch (ClassCastException ex) {
	    return null;
	}

	if (! special) old = super.put(key, val);

	return old;
    }

    public static void main(String args[]) {

	CoordMetadata cmd = new CoordMetadata();
	CoordAxisPos deffmt = new GenericCoordAxisPos();
	double[] voxsz = { 1.0, 1.0, 1.0 };
	String key;
	Object val;

	cmd.setNaxes(2);
	cmd.setName("Inner Space");
	cmd.setAxname(1, "Dharma");
	cmd.setAxname(0, "Karma");
	cmd.setAxlabel(0, "Blinky");
	cmd.setAxlabel(2, "Nod");
	cmd.setAxformat(1, deffmt);
	cmd.setRefvoxel(2, 8.2);
	cmd.setRefvoxel(1, 5.0);
	cmd.setRefvoxel(0, -3);
	cmd.put("voxelsize", voxsz);
	cmd.put("projection", new String("flat"));
	cmd.setRefposition(1, 42);

	StringBuffer out;
	int l;
	for(Enumeration e = cmd.keys(); e.hasMoreElements();) {
	    key = (String) e.nextElement();
	    val = cmd.getMetadatum(key);
	    out = new StringBuffer(key + ": ");
	    l = out.length();
	    if (val instanceof String[]) {
		String[] v = ((String[]) val);
		out.append(v[0]);
		for(int i=1; i < v.length; i++) {
		    out.append("\n");
		    for(int j=0; j < l; j++) out.append(" ");
		    out.append(v[i]);
		}
	    }
	    else if (val instanceof double[]) {
		double[] v = ((double[]) val);
		out.append(v[0]);
		for(int i=1; i < v.length; i++) {
		    out.append("\n");
		    for(int j=0; j < l; j++) out.append(" ");
		    out.append(v[i]);
		}
	    }
	    else if (val instanceof CoordAxisPos[]) {
		CoordAxisPos[] v = ((CoordAxisPos[]) val);
		out.append(v[0]);
		for(int i=1; i < v.length; i++) {
		    out.append("\n");
		    for(int j=0; j < l; j++) out.append(" ");
		    out.append(v[i]);
		}
	    }
	    else {
		out.append(val);
	    }
		
	    System.out.println(out);
	}

	out = new StringBuffer("changing naxes from " + cmd.getNaxes() + 
			       " to ");
	cmd.put("naxes", new Integer(3));
	out.append((Integer)cmd.getMetadatum("naxes"));
	System.out.println(out);
    }
}
