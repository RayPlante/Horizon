/*
 * NCSA Horizon Image Browser
 * Project Horizon
 * National Center for Supercomputing Applications
 * University of Illinois at Urbana-Champaign
 * 605 E. Springfield, Champaign IL 61820
 * horizon@ncsa.uiuc.edu
 *
 * Copyright (C) 1996, Board of Trustees of the University of Illinois
 *
 * NCSA Horizon software, both binary and source (hereafter, Software) is
 * copyrighted by The Board of Trustees of the University of Illinois
 * (UI), and ownership remains with the UI.
 *
 * You should have received a full statement of copyright and
 * conditions for use with this package; if not, a copy may be
 * obtained from the above address.  Please see this statement
 * for more details.
 *
 */
package ncsa.horizon.coordinates;

import ncsa.horizon.util.Metadata;
import ncsa.horizon.util.CorruptedMetadataException;
import ncsa.horizon.coordinates.coordaxispos.GenericCoordAxisPos;
import java.util.*;

/**
 * a CoordMetadata object for standard Computer Graphics Images 
 * (e.g. GIF, JPEG, etc.).  <p>
 *
 * A no-argument constructor will set up CompGraphicsCoordMetadata
 * object suitable for input to a GenCoordinateSystem constructor
 * with the following default values:
 * <pre>
 *     Key            Value                        Type
 *     ----------------------------------------------------------
 *     naxes          2                            Integer
 *     name           "Computer Graphics Image"    String
 *     refvoxel       {0, 0}                       double[]
 *     refposition    {1, 1}                       double[]
 *     voxelsize      {1, 1}                       double[]
 *     axnames        {"X-Axis", "Y-Axis"}         String[]
 *     axformats      {GenericCoordAxisPos, GenericCoordAxisPos}
 *                                                 CoordAxisPos[]
 * </pre>
 *
 * The user may override these defaults and add other metadata either 
 * using the CompGraphicsCoordMetadata(Metadata) constructor or any
 * of the methods inherited from CoordMetadata (and Metadata).
 */
public class CompGraphicsCoordMetadata extends CoordMetadata {

    /**
     * create a default CompGraphicsCoordMetadata object.
     */
    public CompGraphicsCoordMetadata() {
	this(null);
    }

    /**
     * create a CompGraphicsCoordMetadata object.
     * @param inMdata metadata to override or add to defaults
     */
    public CompGraphicsCoordMetadata(Metadata inMdata) {

	super();

	// set up top level values with default values
	CoordAxisPos prtr = new GenericCoordAxisPos();
	setNaxes(2);
	setName("Computer Graphics Image");
	setAxname(0, "X-Axis");
	setAxname(1, "Y-Axis");
	setAxformat(0, prtr);
	setAxformat(1, prtr);
	setRefvoxel(0, 0);
	setRefvoxel(1, 0);
	setVoxelsize(0, 1);
	setVoxelsize(1, 1);
	setRefposition(0, 0);
	setRefposition(1, 0);

	// now place copies of the defaults into the internal default 
	// Metadata object
	CoordMetadata mdata = new CoordMetadata();
	mdata.setNaxes(2);
	mdata.setName("Computer Graphics Image");
	mdata.setAxname(0, "X-Axis");
	mdata.setAxname(1, "Y-Axis");
	mdata.setAxformat(0, prtr);
	mdata.setAxformat(1, prtr);
	mdata.setRefvoxel(0, 0);
	mdata.setRefvoxel(1, 0);
	mdata.setVoxelsize(0, 1);
	mdata.setVoxelsize(1, 1);
	mdata.setRefposition(0, 0);
	mdata.setRefposition(1, 0);
	defaults = mdata;

	// override the top level values with those specified by user
	if (inMdata != null) {
	    for (Enumeration e = inMdata.keys() ; e.hasMoreElements() ;) {
		String key = (String)e.nextElement();
		put(key, inMdata.getMetadatum(key));
	    }
	}
    }

//    public Metadata getDefaults() { return defaults; }
}
