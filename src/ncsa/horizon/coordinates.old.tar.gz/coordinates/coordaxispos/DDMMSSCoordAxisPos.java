/*
 * NCSA Horizon Image Browser
 * Project Horizon
 * National Center for Supercomputing Applications
 * University of Illinois at Urbana-Champaign
 * 605 E. Springfield, Champaign IL 61820
 * horizon@ncsa.uiuc.edu
 *
 * Copyright (C) 1996, Board of Trustees of the University of Illinois
 *
 * NCSA Horizon software, both binary and source (hereafter, Software) is
 * copyrighted by The Board of Trustees of the University of Illinois
 * (UI), and ownership remains with the UI.
 *
 * You should have received a full statement of copyright and
 * conditions for use with this package; if not, a copy may be
 * obtained from the above address.  Please see this statement
 * for more details.
 *
 */
package ncsa.horizon.coordinates.coordaxispos;

import java.util.StringTokenizer;
import ncsa.horizon.coordinates.*;

/**
 * support for printing out angles in degrees:minutes:seconds format
 */
public class DDMMSSCoordAxisPos implements CoordAxisPos {
    public DDMMSSCoordAxisPos() { super(); }

    public String valStr(double degrees, int prec) { 

	int sign = (degrees == 0) ? 1 : (int) (degrees / Math.abs(degrees));
	degrees = Math.abs(degrees);

	int dd = (int)degrees;
	int mm = (int)( (degrees - dd) * 60.0 );
	double ss = (degrees - dd - mm/60.0) * 3600.0;

	// correct for formating errors caused by rounding
	if (ss > 59.99999) { 
	    ss = 0;
	    mm += 1;
	    if (mm >= 60) {
		mm = 0;
		dd += 1;
	    }
	}

	StringBuffer out = new StringBuffer();
	if (sign < 0) out.append("-");
	out.append(dd);
	if (prec == -2) return out.toString();

	out.append(":");
	if (mm < 10) out.append("0");
	out.append(mm);
	if (prec == -1) return out.toString();

	out.append(":");
	if (ss < 10) out.append("0");
	if (prec < -2) {
	    if (ss < 0.000099) 
		out.append("0.0000");
	    else
		out.append(ss);
	}
	else {

	    // specific precision requested; NOT YET SUPPORTED
	    out.append( ss );
	}

	return out.toString();
    }

    public String valStr(double degrees) { 
	return valStr(degrees, -3);
    }

    public double valueOf(String s) throws NumberFormatException {
	if (s == null) throw new NumberFormatException(s);

	double[] vals = new double[3];
	double out = 0;
	int i, sign;

	StringTokenizer factory = new StringTokenizer(s, ":");
	for(i=0; i<3; i++) vals[i] = 0;
	for(i=0; i<3 && factory.hasMoreTokens(); i++) {
	    vals[i] = Double.valueOf(factory.nextToken()).doubleValue();
	}

	sign = (vals[0] < 0) ? -1 : 1;
	out += vals[0] + sign*(vals[1]/60.0 + vals[2]/3600.0);

	return out;
    }

    public Object clone() { return new DDMMSSCoordAxisPos(); }

    protected static final String myname = 
        "Degree-Angle (+/- 90) Coordinate Axis Position Formatter";
    public String toString() { return myname; }

    public static void main(String args[]) {
	int i;
	CoordAxisPos cap = new DDMMSSCoordAxisPos();

	double mine = 149.9823;
	System.out.println("My position: " + cap.valStr(mine));

	double yours;
	for (i=0; i < args.length; i++) {
	    yours = new Double(args[i]).doubleValue();
	    System.out.println("Your position: " + cap.valStr(yours));
	}
    }
};

