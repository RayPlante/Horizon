/*
 * NCSA Horizon Image Browser
 * Project Horizon
 * National Center for Supercomputing Applications
 * University of Illinois at Urbana-Champaign
 * 605 E. Springfield, Champaign IL 61820
 * horizon@ncsa.uiuc.edu
 *
 * Copyright (C) 1996, Board of Trustees of the University of Illinois
 *
 * NCSA Horizon software, both binary and source (hereafter, Software) is
 * copyrighted by The Board of Trustees of the University of Illinois
 * (UI), and ownership remains with the UI.
 *
 * You should have received a full statement of copyright and
 * conditions for use with this package; if not, a copy may be
 * obtained from the above address.  Please see this statement
 * for more details.
 *
 */
package ncsa.horizon.coordinates.coordaxispos;

import ncsa.horizon.coordinates.*;

/**
 * support for printing out double values as floating point numbers.
 */
public class GenericCoordAxisPos implements CoordAxisPos {
    public GenericCoordAxisPos() { super(); }

    public String valStr(double val) { return Double.toString(val); }
    public String valStr(double val, int prec) { 

	// precision not yet supported
	return Double.toString(val); 
    }

    public double valueOf(String s) throws NumberFormatException {
	Double out = Double.valueOf(s);
	return out.doubleValue();
    }

    public Object clone() { return new GenericCoordAxisPos(); }

    public static void main(String args[]) {
	int i;
	CoordAxisPos cap = new GenericCoordAxisPos();

	double mine = 152.2345;
	System.out.println("My position: " + cap.valStr(mine));

	double yours;
	for (i=0; i < args.length; i++) {
	    yours = new Double(args[i]).doubleValue();
	    System.out.println("Your position: " + cap.valStr(yours));
	}
    }

    protected static final String myname = 
        "Generic Coordinate Axis Position Formatter";
    public String toString() { return myname; }
};

