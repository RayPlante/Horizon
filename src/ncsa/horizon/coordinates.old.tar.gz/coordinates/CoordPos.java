/*
 * NCSA Horizon Image Browser
 * Project Horizon
 * National Center for Supercomputing Applications
 * University of Illinois at Urbana-Champaign
 * 605 E. Springfield, Champaign IL 61820
 * horizon@ncsa.uiuc.edu
 *
 * Copyright (C) 1996, Board of Trustees of the University of Illinois
 *
 * NCSA Horizon software, both binary and source (hereafter, Software) is
 * copyrighted by The Board of Trustees of the University of Illinois
 * (UI), and ownership remains with the UI.
 *
 * You should have received a full statement of copyright and
 * conditions for use with this package; if not, a copy may be
 * obtained from the above address.  Please see this statement
 * for more details.
 *
 */
package ncsa.horizon.coordinates;

import java.util.*;
import ncsa.horizon.util.Metadata;
import ncsa.horizon.util.OneWayWriteProtection;
import ncsa.horizon.util.WriteProtectionException;
import ncsa.horizon.util.MetadataTypeException;

/**
 * support for accessing a representation (string or double) of a position
 * in a coordinate system. <P>
 *
 * A CoordPos object represents a position in a coordinate space.  Such an 
 * object is often returned by Coordinate object methods and can be handed
 * back to a Coordinate object for conversion to a data voxel location.  
 * One of the most useful features of the CoordPos object is that is knows
 * how to format itself as a string.  Code to print out parts of the 
 * CoordPos's value might look something like this:
 * <pre>
 *    CoordPos wcspos;
 *    ...
 *    wcspos = wcs.getCoordPos(datapos);
 *    System.out.println( wcspos.axisLabel(0) +   // print position
 *                        ": " +                  //  along 1st axis
 *                        wcspos.valStr(0) );     
 *    System.out.println( wcspos.axisLabel(1) +   // print position
 *                        ": " +                  //  along 2nd axis
 *                        wcspos.valStr(1) );     
 * </pre>
 * which might produce something the following:
 * <pre>
 *    RA: 12:45:39.11
 *    Dec: -30:17:20.2
 * </pre>
 * Note: see section below on "Axis Numbering Convention". <p>
 *
 * Position values as doubles can be both retrieved and set.  (Note that 
 * write protection does not prevent one from updating the value of 
 * coordinate position with setValue() and setValues(); see sections below
 * for more information on write protection.) <p>
 *
 * <b> Coordinate Metadata </b><p>
 *
 * Coordinate and CoordPos objects maintain internal Metadata objects
 * that hold named data describing the coordinate system and are usually
 * set when the Coordinate or CoordPos object is instantiated.  The
 * Metadata object can contain any data (of any type) relevent to the 
 * particular system; however, certain data specifically related to all
 * coordinate systems are expected to be of a certain type:
 *
 * <pre>
 *   <b>Key name</b>       <b>Type</b>             <b>Description</b> 
 *  *naxes          Integer          number of axes
 *   axnames        String[]         names identifying each axis
 *   axlabels       String[]         labels for each axis 
 *                                   (when printing positions)
 *   axformats      CoordAxisPos[]   position formatting objects for each
 *                                   axis (when printing positions)
 *   name           String           Arbitrary name for system
 * <br>
 *  *must be specified for all Coordinate and CoordPos objects.
 * </pre>
 *
 * Specific instantiations of Coordinate and CoordPos objects may expect
 * other metadata of specific types.  In general however, when the 
 * metadata are needed but not specified, sensible defaults are used, 
 * except for "naxes" which must always be set (> 0) or an 
 * ArrayIndexOutOfBoundsException may be thrown. <p>
 *
 * Normally, the CoordPos Metadata object is write-protected (i.e. calling 
 * addMetadata() will throw a WriteProtectionException); this keeps objects
 * with references to the same CoordPos object from confusing each other.  
 * To add or update the metadata of a CoordPos object, one should first 
 * make a copy with clone(); the new copy will have write protection turned 
 * off.  After the metadata has been updated, writeProtect() should be called
 * to protect from future possible updates.  <p>
 *
 * <b> Axis Numbering Convention </b><p>
 *
 * The default convention used for indexing axes (honored by axisLabel(int),
 * value(int), valStr(int), and setValue(int, double)) is controlled by 
 * the protected field firstAxisIndex, the index to be used for the first 
 * axis, and is set when the object is constructed.  (The current value of 
 * the field is obtained via getFirstAxisIndex().)  One usually sets this to 
 * either 0 or 1, but it can be set to any integer.  (A firstAxisIndex<0 is 
 * a good way to confuse oneself.)  Horizon objects that create and return 
 * CoordPos objects use firstAxisIndex=0.  <p>
 *
 * Normally, this field is write-protected, i.e. calling 
 * setFirstAxisIndex(int) will throw a WriteProtectionException; this keeps 
 * objects with references to the same CoordPos object from confusing each 
 * other.  To change the indexing convention, one can first make a copy with 
 * clone(); the new copy will have write protection turned off.  After 
 * calling setFirstAxisIndex(int), writeProtect() should be called
 * to protect from future possible updates.  Alternatively, one can use the
 * methods axisLabels(int), values(int), and setValues(double[], int) which
 * allow the caller to specify the convention to be used.  <p>
 *
 */
public abstract class CoordPos implements Cloneable, OneWayWriteProtection {

    /**
     * default index of the first axis.  For example, the index argument
     * given to axisLabel(int) should be relative to the value of 
     * firstAxisIndex.  Also, the firstAxisIndex field of the CoordPos 
     * objects returned by getCoordPos will be set to this value.
     */
    protected int firstAxisIndex=0;

    /** return the index of the first axis (as defined during this object's 
     *  construction).
     **/
    public int getFirstAxisIndex() { return firstAxisIndex; }

    /** 
     * set the index of the first axis 
     * @param firstaxis default index of the first axis
     * @exception WriteProtectionException if writeProtect() was called
     */
    public abstract void setFirstAxisIndex(int firstaxis) 
	throws WriteProtectionException;

    /**
     * return the number of axes in the space containing this position
     */
    public abstract int getNaxes();

    /**
     * return the label of an axis
     * @param axis the axis of interest; axes are numbered beginning with 0.
     */
    public abstract String axisLabel(int axis) 
	throws ArrayIndexOutOfBoundsException;

    /**
     * return the axis labels as an array of strings
     * @param firstaxis the index at which the label of the first axis 
     *                  should appear in the returned array
     * @exceptions ArrayIndexOutOfBoundsException if firstaxis < 0
     */
    public abstract String[] axisLabels(int firstaxis)
	throws ArrayIndexOutOfBoundsException;

    /**
     * return the axis labels as an array of strings.  The index of the 
     * label for the first axis will be the the larger of firstAxisIndex 
     * and zero.
     */
    public String[] axisLabels(){ 
	return (firstAxisIndex < 0) ? axisLabels(0) : 
	                              axisLabels(firstAxisIndex);
    }

    /**
     * return a formatted string containing the position's projection along
     * an axis
     * @param axis the axis of interest; axes are numbered beginning with 
     *             the value of firstAxisIndex.
     */
    public abstract String valStr(int axis) 
	throws ArrayIndexOutOfBoundsException;

    /**
     * return an array of formatted strings containing the position's 
     * projection along each axis
     * @param firstaxis the index at which the string for the first axis
     *                  should appear in the output array
     */
    public abstract String[] valStrs(int firstaxis) 
	throws ArrayIndexOutOfBoundsException;

    /**
     * return an array of formatted strings containing the position's 
     * projection along each axis.  The index of the string for the first
     * axis will be the value of firstAxisIndex
     */
    public String[] valStrs() {
	return (firstAxisIndex < 0) ? valStrs(0) : 
	                              valStrs(firstAxisIndex); 
    }

    /**
     * return a double containing the position's projection along
     * an axis
     * @param axis the axis of interest; axes are numbered beginning with 
     *             the value of firstAxisIndex.
     */
    public abstract double value(int axis) 
	throws ArrayIndexOutOfBoundsException;

    /**
     * set the position's projection along an axis to a value
     * @param axis the axis of interest; axes are numbered beginning with 0.
     * @param newval the new value
     */
    public abstract void setValue(int axis, double newval) 
	throws ArrayIndexOutOfBoundsException;

    /**
     * return an array of doubles representing the position along each
     * axis
     * @param firstaxis the index at which the value for the first axis 
     *                  should appear in the returned array
     */
    public abstract double[] values(int firstaxis)
	throws ArrayIndexOutOfBoundsException;

    /**
     * return an array of doubles representing the position along each
     * axis
     */
    public double[] values() throws ArrayIndexOutOfBoundsException {
	return (firstAxisIndex < 0) ? values(0) : 
	                              values(firstAxisIndex); 
    }

    /**
     * set the position along all axes with the values given in the input
     * array, returning the old values;
     * @param newpos array containing values of the new position
     * @param firstaxis the index for the first axis in newpos
     * @exception ArrayIndexOutOfBoundsException if firstaxis < 0;
     */
    public abstract void setValues(double[] newpos, int firstaxis)
	throws ArrayIndexOutOfBoundsException;

    /**
     * set the position along all axes with the values given in the input
     * array.  The index of the value for the first axis should be 
     * firstAxisIndex or zero, which ever is greater.  
     */
    public void setValues(double[] newpos) {
	if (firstAxisIndex < 0)
	    setValues(newpos, 0);
	else
	    setValues(newpos, firstAxisIndex);
    }

    /**
     * return a MetaData object that identifies this coordinate 
     * system.  
     */
    public abstract Metadata getMetadata();

    /**
     * set the MetaData object for this coordinate system
     * @exception WriteProtectionException if writeProtect() was called 
     * @exception MetadataTypeException if an input metadatum with an 
     *            expected key name is of an unexpected type.
     */
    public abstract void addMetadata(Metadata mdata) 
	throws WriteProtectionException, MetadataTypeException;

    /**
     * clone this object.  The CoordPos returned will have write protection
     * turned off, allowing one to call setFirstAxisIndex() and addMetadata().
     */
    public abstract Object clone();

    /** 
     * turn on write protection of the metadata and the firstAxisIndex field
     * for this CoordPos object (i.e. do not allow calls to addMetadata()
     * and setFirstAxisIndex()).
     * @return whether the write protection was changed
     */
    public abstract boolean writeProtect();

    /**
     * return whether write protection of the metadata for this 
     * CoordPos object is on (i.e. whether calls to addMetadata()
     * and setFirstAxisIndex() are allowed).
     */
    public abstract boolean isWriteProtected();
};

