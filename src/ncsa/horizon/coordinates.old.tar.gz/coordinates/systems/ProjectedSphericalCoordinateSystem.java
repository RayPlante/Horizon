/*
 * NCSA Horizon Image Browser
 * Project Horizon
 * National Center for Supercomputing Applications
 * University of Illinois at Urbana-Champaign
 * 605 E. Springfield, Champaign IL 61820
 * horizon@ncsa.uiuc.edu
 *
 * Copyright (C) 1996, Board of Trustees of the University of Illinois
 *
 * NCSA Horizon software, both binary and source (hereafter, Software) is
 * copyrighted by The Board of Trustees of the University of Illinois
 * (UI), and ownership remains with the UI.
 *
 * You should have received a full statement of copyright and
 * conditions for use with this package; if not, a copy may be
 * obtained from the above address.  Please see this statement
 * for more details.
 *
 */
package ncsa.horizon.coordinates.systems;

import java.util.*;
import ncsa.horizon.util.Metadata;
import ncsa.horizon.util.CorruptedMetadataException;
import ncsa.horizon.coordinates.*;
import ncsa.horizon.coordinates.coordaxispos.GenericCoordAxisPos;
import ncsa.horizon.coordinates.coordaxispos.HHMMSSCoordAxisPos;
import ncsa.horizon.coordinates.coordaxispos.DDMMSSCoordAxisPos;
import FITSWCS.*;
import FITSWCS.exceptions.*;

/**
 * a coordinate system where two axes describe a spherical surface 
 * (i.e. a longitude and latitude) projected onto a tangent plane and 
 * the remaining axes are linear. 
 */
public class ProjectedSphericalCoordinateSystem extends GenCoordinateSystem 
    implements ProjectionType
{

    protected int longaxis, lataxis;
    protected Projection prj=null;
    protected LinearTransform lin;
    protected SphericalTransform sph;
//    protected double[] euler;

    /**
     * create a ProjectedSphericalCoordinateSystem.
     * @param mdata the set of metadata that describes the Coordinate system
     *              Note that expected metadata keys of the wrong type are 
     *              ignored (see above).
     * @param longname   the name given to the longitude axis.
     * @param latname    the name given to the latitude axis.
     * @param calm  if true, a "linear" projection will be used if the 
     *              value of the "projection" metadatum is either not set 
     *              is not recognized as a supported projection type; 
     *              otherwise, an UnsupportedCoordinateSystemException will 
     *              be thrown.
     * @param firstAxisIndex  the initial value of firstAxisIndex, the 
     *              default index for the first axis.
     */
    public ProjectedSphericalCoordinateSystem(String longname, String latname, 
					Metadata mdata, boolean calm,
					int firstAxisIndex) 
	throws ArrayIndexOutOfBoundsException, CorruptedMetadataException,
	       UnsupportedCoordinateSystemException, BadCoordinateDataException
    {
	super(mdata, firstAxisIndex);
	setThis(longname, latname, mdata, calm);
    }

    /**
     * create a ProjectedSphericalCoordinateSystem; same as 
     * ProjectedSphericalCoordinateSystem(longname, latname, mdata, 
     *                                    true, firstaxis);
     * that is, neither UnsupportedCoordinateSystemException nor 
     * BadCoordinateDataException will be thrown.
     */
    public ProjectedSphericalCoordinateSystem(String longname, String latname, 
					Metadata mdata, int firstaxis) 
	throws ArrayIndexOutOfBoundsException, CorruptedMetadataException
    {
	super(mdata, firstaxis);
	try {
	    setThis(longname, latname, mdata, true);
	} 
	catch (UnsupportedCoordinateSystemException ex) { }
	catch (BadCoordinateDataException ex) { }
    }

    /**
     * create a ProjectedSphericalCoordinateSystem; same as 
     * ProjectedSphericalCoordinateSystem(longname, latname, mdata, true, 0);
     * that is, neither UnsupportedCoordinateSystemException nor 
     * BadCoordinateDataException will be thrown.
     */
    public ProjectedSphericalCoordinateSystem(String longname, String latname, 
					Metadata mdata) 
	throws ArrayIndexOutOfBoundsException, CorruptedMetadataException
    {
	this(longname, latname, mdata, 0);
    }

    /**
     * create a ProjectedSphericalCoordinateSystem.
     * @param mdata the set of metadata that describes the Coordinate system
     *              Note that expected metadata keys of the wrong type are 
     *              ignored (see above).
     * @param longaxis   the index of the longitude axis (0 = first axis).
     * @param lataxis    the index of the latitude axis (0 = first axis).
     * @param calm  if true, a "linear" projection will be used if the 
     *              value of the "projection" metadatum is either not set 
     *              is not recognized as a supported projection type; 
     *              otherwise, an UnsupportedCoordinateSystemException will 
     *              be thrown.
     * @param firstAxisIndex  the initial value of firstAxisIndex, the 
     *              default index for the first axis.
     */
    public ProjectedSphericalCoordinateSystem(int longaxis, int lataxis, 
					Metadata mdata, boolean calm,
					int firstAxisIndex) 
	throws ArrayIndexOutOfBoundsException, CorruptedMetadataException,
	       UnsupportedCoordinateSystemException, BadCoordinateDataException
    {
	super(mdata, firstAxisIndex);
	setThis(longaxis, lataxis, mdata, calm);
    }

    /**
     * create a ProjectedSphericalCoordinateSystem; same as 
     * ProjectedSphericalCoordinateSystem(longaxis, lataxis, mdata, 
     *                                    true, firstaxis);
     * that is, neither UnsupportedCoordinateSystemException nor 
     * BadCoordinateDataException will be thrown.
     */
    public ProjectedSphericalCoordinateSystem(int longaxis, int lataxis, 
					Metadata mdata, int firstaxis)
	throws ArrayIndexOutOfBoundsException, CorruptedMetadataException
    {
	super(mdata, firstaxis);
	try {
	    setThis(longaxis, lataxis, mdata, true);
	} 
	catch (UnsupportedCoordinateSystemException ex) { }
	catch (BadCoordinateDataException ex) { }
    }

    /**
     * create a ProjectedSphericalCoordinateSystem; same as 
     * ProjectedSphericalCoordinateSystem(longaxis, lataxis, mdata, true, 0);
     * that is, neither UnsupportedCoordinateSystemException nor 
     * BadCoordinateDataException will be thrown.
     */
    public ProjectedSphericalCoordinateSystem(int longaxis, int lataxis, 
					Metadata mdata)
	throws ArrayIndexOutOfBoundsException, CorruptedMetadataException
    {
	this(longaxis, lataxis, mdata, 0);
    }

    /**
     * used to actually construct this object
     */
    private void setThis(String longname, String latname, Metadata mdata, 
			 boolean calm) 
	throws ArrayIndexOutOfBoundsException, CorruptedMetadataException,
	       UnsupportedCoordinateSystemException, BadCoordinateDataException
    {
	Integer ival;
	int i;

	ival = CoordConverter.exactMatchingAxis(mdata, longname);
	if (ival == null) 
	    throw new CorruptedMetadataException("axnames", 
		 "No axis name matching \"" + longname + "\"");
	i = ival.intValue();
	if (i < 0 || i >= naxes) throw new ArrayIndexOutOfBoundsException(i);

	longaxis = i;

	ival = CoordConverter.exactMatchingAxis(mdata, latname);
	if (ival == null) 
	    throw new CorruptedMetadataException("axnames", 
		 "No axis name matching \"" + latname + "\"");
	i = ival.intValue();
	if (i < 0 || i >= naxes) throw new ArrayIndexOutOfBoundsException(i);

	longaxis = i;

	init(calm);
    }

    /**
     * used to actually construct this object
     */
    private void setThis(int longaxis, int lataxis, Metadata mdata, 
			 boolean calm) 
	throws ArrayIndexOutOfBoundsException, CorruptedMetadataException,
	       UnsupportedCoordinateSystemException, BadCoordinateDataException
    {
	if (longaxis < 0 || longaxis >= naxes) 
	    throw new ArrayIndexOutOfBoundsException(longaxis);
	this.longaxis = longaxis;
	if (lataxis < 0 || lataxis >= naxes) 
	    throw new ArrayIndexOutOfBoundsException(lataxis);
	this.lataxis = lataxis;

	init(calm);
    }

    /**
     * set the projection type; if calm is not true, throw an exception if
     * the projection given in as the projection metadatum is either not
     * specified or unrecognized as a supported type.
     */
    private String setProjection(boolean calm) throws
	UnsupportedProjectionException, BadProjectionParameterException
    {
	String prjname;
	double[] projp;
	boolean badprojp=false;

	// get projection parameters, if available;
	try {
	    projp = (double[]) defmdata.getMetadatum("projparm");
	} 
	catch (ClassCastException ex) {
	    projp = null;
	    if (! calm) throw new CorruptedMetadataException("projparm", 
							     "Unexpected type");
	    System.out.println("Warning: unable to read projection parameters");
	}

	try {
	    prjname = ((String) defmdata.getMetadatum("projection")).trim();
	} catch (ClassCastException ex) {
	    prjname = null;
	}

	// set the projection transform to be used
	try {
	    prj = Projection.getProjection(prjname, projp);
	}
	catch (UnsupportedProjectionException ex) {
	    prj = null;
	    if (! calm) throw ex;
	    System.out.println("Warning: Unsupported Projection; using linear");
	}
	catch (BadProjectionParameterException ex) {
	    prj = null;
	    if (! calm) throw ex;
	    System.out.println("Warning: " + ex.getMessage() + 
			       "; using linear mapping");
	}
	catch (ArrayIndexOutOfBoundsException ex) {
	    prj = null;
	    if (! calm) 
		throw new BadProjectionParameterException(ex.getMessage());
	    System.out.println("Warning: " + ex.getMessage() + 
			       "; using linear mapping");
	}

	return prjname;
    }

    private void init(boolean calm) throws 
	UnsupportedCoordinateSystemException, BadCoordinateDataException
    {
	double[][] txmat;
	double[] vxsz, refvx;
	String key, pcode;

	/*
         * Prep the linear transfromation
	 */

	// get the linear translation matrix, if available
	try {
	    txmat = (double[][]) defmdata.getMetadatum("lintxmatrix");
	} catch (ClassCastException ex) {
	    if (! calm) throw new CorruptedMetadataException("lintxmatrix", 
							    "Unexpected type");
	    txmat = null;
	}

	// get the linear transformer we will use
	try {
	    lin = new LinearTransform(naxes, refvoxel, txmat, voxelsize);
	} catch (SingularMatrixException ex) {
	    if (! calm) throw new 
		BadCoordinateDataException("Bad linear transform matrix: " + 
					   ex.getMessage());
	    System.out.println("Warning: Bad linear transform matrix: " +
			      ex.getMessage() + "\n will disregard transform");
	    try {
		lin = new LinearTransform(naxes, refvoxel,
					  (double[][]) null, voxelsize);
	    } catch (SingularMatrixException exx) {
		throw new InternalError("Programmer Error: LinearTransform");
	    }
	}

	/*
	 * Prep the projection transformation
	 */

	// set projection transformer object
	try {
	    pcode = setProjection(calm);
	}
	catch (BadProjectionParameterException ex) {
	    throw new BadCoordinateDataException("Bad Projection: " + 
						 ex.getMessage());
	}
	catch (UnsupportedProjectionException ex) {
	    throw new UnsupportedCoordinateSystemException("Projection: " +
							   ex.getMessage());
	}

	/*
	 * Prep the spherical transformation.  Note that the spherical 
	 * rotation is done with static functions
	 */
	try {
	    try {
		sph = new SphericalTransform(refposition[longaxis], 
					     refposition[lataxis], pcode);
	    }
	    catch (UnsupportedProjectionException ex) {

		// should not happen
		if (! calm) throw new 
		    UnsupportedCoordinateSystemException("Projection: " +
							 ex.getMessage());
		sph = new SphericalTransform(refposition[longaxis],
					     refposition[lataxis]);
	    }
	}
	catch (BadReferenceParameterException ex) {
	    if (! calm) throw new 
		BadCoordinateDataException("Bad Reference Position: " +
					   ex.getMessage());
	    System.out.println("Warning: Bad Reference Position: " +
			       ex.getMessage());
	    try {
		sph = new SphericalTransform(0,90);
	    } catch (BadReferenceParameterException exx) {
		throw new InternalError("Programmer Error: " +
					"Bad default SphericalTransform");
	    }
	}
    }

    /**
     * get coordinate position corresponding to a particular data
     * location <p>
     * Note to sub-classers: this actually calculates the position;
     * if one overrides this function, getCoordVal(), getCoordPos()
     * will effectively inherit the new behavior.
     * @param pos location in the data space as a double[]
     * @param firstaxis the index at which the value for the first axis 
     *            appears in pos and should appear in the returned array.
     * @returns double[] coordinate position as an array of doubles
     * @exception ArrayIndexOutOfBoundsException if firstaxis < 0;
     */
    public double[] getCoordVal(double[] pos, int firstaxis) 
	throws ArrayIndexOutOfBoundsException
    {
	if (firstaxis < 0) throw new ArrayIndexOutOfBoundsException(
	    "Requested first axis index < 0: " + firstaxis);

	double[] use;
	if (firstaxis == 0) {
	    use = pos;
	} else {
	    use = new double[naxes];
	    System.arraycopy(pos, firstaxis, use, 0, 
			     Math.max(pos.length, naxes));
	    for(int i=pos.length; i < naxes; i++) use[i] = 0;
	}

	double[] out = lin.rev(use);
	double[] sppixin = { out[longaxis], out[lataxis] };
	double[] sppixout = { Double.NaN, Double.NaN };
//	double[] out = super.getCoordVal(pos);

	try {
	    sppixout = sph.rev(prj.rev(sppixin));
	}
	catch (PixelBeyondProjectionException ex) { }

	out[longaxis] = sppixout[0];
	out[lataxis]  = sppixout[1];

	if (firstaxis == 0) {
	    use = out;
	} else {
	    use = new double[naxes+firstaxis];
	    System.arraycopy(out, 0, use, firstaxis, out.length);
	}
	    
	return use;
    }

    /**
     * get data location corresponding to a coordinate value <p>
     *
     * Note to sub-classers: this actually calculates the position;
     * if one overrides this function, getVoxelVal(), getVoxel()
     * will effectively inherit the new behavior.
     * @param pos location in the coordinate space as a double[]
     * @param firstaxis the index at which the value for the first axis 
     *            appears in pos and should appear in the returned array.
     * @returns double[] data voxel as an array of doubles
     * @exception ArrayIndexOutOfBoundsException if firstaxis < 0;
     */
    public double[] getVoxelVal(double[] pos, int firstaxis) {
	if (firstaxis < 0) throw new ArrayIndexOutOfBoundsException(
	    "Requested first axis index < 0: " + firstaxis);

	double[] use;
	if (firstaxis == 0) {
	    use = pos;
	} else {
	    use = new double[naxes];
	    System.arraycopy(pos, firstaxis, use, 0, 
			     Math.max(pos.length, naxes));
	    for(int i=pos.length; i < naxes; i++) use[i] = 0;
	}

	double[] sppixin = { use[longaxis], use[lataxis] };
	double[] sppixout = { Double.NaN, Double.NaN };

	try {
	    sppixout = prj.fwd(sph.fwd(sppixin));
	}
	catch (PixelBeyondProjectionException ex) { }

	use[longaxis] = sppixout[0];
	use[lataxis]  = sppixout[1];
	double[] out = lin.fwd(use);

	if (firstaxis == 0) {
	    use = out;
	} else {
	    use = new double[naxes+firstaxis];
	    System.arraycopy(out, 0, use, firstaxis, out.length);
	}

	return use;
    }

    public static void main(String args[]) {

	String sp;
	int i;
	CoordinateSystem space;
	String names[] = { "RA--SIN", "Dec-Sin", "Velo" };
	double[] refvox = { 45.7, 23.0, 18.0 },
		 refpos = { 120.0, 30.0, 100.0 },
		 voxsz  = { 1/3600.0, 1/3600.0, 5.0 },
		 origin = { 0.0, 0.0, 0.0 };
	CoordAxisPos frmtrs[] = { new HHMMSSCoordAxisPos(),
				  new DDMMSSCoordAxisPos(),
				  new GenericCoordAxisPos() };
	Metadata mdata = new Metadata();
	mdata.put(new String("space"), new String("Celestial-Velocity"));

	mdata.put(new String("naxes"), new Integer(3));
	mdata.put(new String("axnames"), names);
	mdata.put(new String("refposition"), refpos);
	mdata.put(new String("refvoxel"), refvox);
	mdata.put(new String("voxelsize"), voxsz);
	mdata.put(new String("axformats"), frmtrs);
	mdata.put("projection", "SIN");

	space = new ProjectedSphericalCoordinateSystem(0,1,mdata);

	CoordPos mycp = space.getCoordPos(origin);
	sp = (String) mycp.getMetadata().getMetadatum(new String("space"), 
			    	                      new String("my"));
	System.out.println("My position in " + sp + " space...");
	for (i=0; i < mycp.getNaxes(); i++) {
	    System.out.println("  " + mycp.axisLabel(i) + 
			       ": " + mycp.valStr(i)      );
	}
	if (args.length <= 0) System.exit(0);

	double[] yours = new double[args.length];
	for(i=0; i < args.length; i++) {
	    yours[i] = new Double(args[i]).doubleValue();
	}

	CoordPos yourcp = space.getCoordPos(yours);
	System.out.println("Your position " + sp + " space...");
	for (i=0; i < yourcp.getNaxes(); i++) {
	    System.out.println("  " + yourcp.axisLabel(i) + 
			       ": " + yourcp.valStr(i)      );
	}
    }

}


