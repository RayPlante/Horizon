/*
 * NCSA Horizon Image Browser
 * Project Horizon
 * National Center for Supercomputing Applications
 * University of Illinois at Urbana-Champaign
 * 605 E. Springfield, Champaign IL 61820
 * horizon@ncsa.uiuc.edu
 *
 * Copyright (C) 1996, Board of Trustees of the University of Illinois
 *
 * NCSA Horizon software, both binary and source (hereafter, Software) is
 * copyrighted by The Board of Trustees of the University of Illinois
 * (UI), and ownership remains with the UI.
 *
 * You should have received a full statement of copyright and
 * conditions for use with this package; if not, a copy may be
 * obtained from the above address.  Please see this statement
 * for more details.
 *
 */
package ncsa.horizon.coordinates.systems;

import java.util.*;
import ncsa.horizon.util.Metadata;
import ncsa.horizon.util.CorruptedMetadataException;
import ncsa.horizon.coordinates.*;
import ncsa.horizon.coordinates.coordaxispos.GenericCoordAxisPos;
import ncsa.horizon.coordinates.coordaxispos.HHMMSSCoordAxisPos;
import ncsa.horizon.coordinates.coordaxispos.DDMMSSCoordAxisPos;

/**
 * a coordinate system where two axes describe a spherical surface 
 * (i.e. a longitude and latitude) and the remaining axes are linear.
 */
public class SphericalCoordinateSystem extends GenCoordinateSystem {

    protected int longaxis, lataxis;

    /**
     * create a SpericalCoordinateSystem with a particular value
     * @param mdata the set of metadata that describes the Coordinate system
     *              Note that expected metadata keys of the wrong type are 
     *              ignored (see above).
     */
    public SphericalCoordinateSystem(String longname, String latname, 
				     Metadata mdata) 
	throws ArrayIndexOutOfBoundsException, CorruptedMetadataException
    {
	super(mdata);

	Integer ival;
	int i;

	ival = CoordConverter.exactMatchingAxis(mdata, longname);
	if (ival == null) 
	    throw new CorruptedMetadataException("axnames", 
		 "No axis name matching \"" + longname + "\"");
	i = ival.intValue();
	if (i < 0 || i >= naxes) throw new ArrayIndexOutOfBoundsException(i);

	longaxis = i;

	ival = CoordConverter.exactMatchingAxis(mdata, latname);
	if (ival == null) 
	    throw new CorruptedMetadataException("axnames", 
		 "No axis name matching \"" + latname + "\"");
	i = ival.intValue();
	if (i < 0 || i >= naxes) throw new ArrayIndexOutOfBoundsException(i);

	lataxis = i;
    }

    public SphericalCoordinateSystem(int longaxis, int lataxis, 
				     Metadata mdata) 
	throws ArrayIndexOutOfBoundsException, CorruptedMetadataException
    {
	super(mdata);
	if (longaxis < 0 || longaxis >= naxes) 
	    throw new ArrayIndexOutOfBoundsException(longaxis);
	this.longaxis = longaxis;
	if (lataxis < 0 || lataxis >= naxes) 
	    throw new ArrayIndexOutOfBoundsException(lataxis);
	this.lataxis = lataxis;
    }

    /**
     * get coordinate position corresponding to a particular data
     * location <p>
     * Note to sub-classers: this actually calculates the position;
     * if one overrides this function, getCoordVal(), getCoordPos()
     * will effectively inherit the new behavior.
     * @param pos location in the coordinate space as a double[]
     */
    public double[] getCoordVal(double[] pos) {

	double[] out = super.getCoordVal(pos);
	double coslat = Math.cos(out[lataxis] * Math.PI / 180.0);
	if (coslat == 0) {
	    out[longaxis] = refposition[longaxis];
	}
	else {
	    out[longaxis] = ( (pos[longaxis] - refvoxel[longaxis]) * 
		     voxelsize[longaxis] ) / coslat + refposition[longaxis];
	}

	return out;
    }

    public static void main(String args[]) {

	String sp;
	int i;
	String names[] = { "RA--SIN", "Dec", "Velo" };
	double[] refvox = { 45.7, 23.0, 18.0 },
		 refpos = { 120.0, 30.0, 100.0 },
		 voxsz  = { 1/3600.0, 1/3600.0, 5.0 },
		 origin = { 0.0, 0.0, 0.0 };
	CoordAxisPos frmtrs[] = { new HHMMSSCoordAxisPos(),
				  new DDMMSSCoordAxisPos(),
				  new GenericCoordAxisPos() };
	Metadata mdata = new Metadata();
	mdata.put(new String("space"), new String("Celestial-Velocity"));

	mdata.put(new String("naxes"), new Integer(3));
	mdata.put(new String("axnames"), names);
	mdata.put(new String("refposition"), refpos);
	mdata.put(new String("refvoxel"), refvox);
	mdata.put(new String("voxelsize"), voxsz);
	mdata.put(new String("axformats"), frmtrs);

	CoordinateSystem space = new SphericalCoordinateSystem(0,1,mdata);

	CoordPos mycp = space.getCoordPos(origin);
	sp = (String) mycp.getMetadata().getMetadatum(new String("space"), 
			    	                      new String("my"));
	System.out.println("My position in " + sp + " space...");
	for (i=0; i < mycp.getNaxes(); i++) {
	    System.out.println("  " + mycp.axisLabel(i) + 
			       ": " + mycp.valStr(i)      );
	}
	if (args.length <= 0) System.exit(0);

	double[] yours = new double[args.length];
	for(i=0; i < args.length; i++) {
	    yours[i] = new Double(args[i]).doubleValue();
	}

	CoordPos yourcp = space.getCoordPos(yours);
	System.out.println("Your position " + sp + " space...");
	for (i=0; i < yourcp.getNaxes(); i++) {
	    System.out.println("  " + yourcp.axisLabel(i) + 
			       ": " + yourcp.valStr(i)      );
	}
    }

}
