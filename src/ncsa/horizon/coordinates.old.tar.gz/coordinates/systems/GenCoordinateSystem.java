/*
 * NCSA Horizon Image Browser
 * Project Horizon
 * National Center for Supercomputing Applications
 * University of Illinois at Urbana-Champaign
 * 605 E. Springfield, Champaign IL 61820
 * horizon@ncsa.uiuc.edu
 *
 * Copyright (C) 1996, Board of Trustees of the University of Illinois
 *
 * NCSA Horizon software, both binary and source (hereafter, Software) is
 * copyrighted by The Board of Trustees of the University of Illinois
 * (UI), and ownership remains with the UI.
 *
 * You should have received a full statement of copyright and
 * conditions for use with this package; if not, a copy may be
 * obtained from the above address.  Please see this statement
 * for more details.
 *
 */
package ncsa.horizon.coordinates.systems;

import ncsa.horizon.util.Metadata;
import ncsa.horizon.util.CorruptedMetadataException;
import ncsa.horizon.coordinates.*;
import ncsa.horizon.coordinates.coordaxispos.GenericCoordAxisPos;
import ncsa.horizon.coordinates.coordaxispos.HHMMSSCoordAxisPos;
import ncsa.horizon.coordinates.coordaxispos.DDMMSSCoordAxisPos;
import ncsa.horizon.coordinates.coordpos.GenCoordPos;
import java.util.*;

/**
 * a generalized linear coordinate system. <p>
 *
 * @see CoordinateSystem for details on example usage and the axis numbering 
 *                 convention.
 */
public class GenCoordinateSystem extends CoordinateSystem {

    protected int naxes=0;
    protected double[] refposition, refvoxel, voxelsize;
    protected Metadata cmdata;
    protected Metadata defmdata;
    private static GenericCoordAxisPos defPosPrinter = 
                                                new GenericCoordAxisPos();

    /**
     * create a GenCoordinateSystem with a particular value
     * @param mdata the set of metadata that describes the Coordinate system
     *              Note that expected metadata keys of the wrong type are 
     *              ignored (see above).
     * @param firstAxisIndex the initial value of firstAxisIndex, the default 
     *              index for the first axis.
     */
    public GenCoordinateSystem(Metadata mdata, int firstAxisIndex) 
	throws ArrayIndexOutOfBoundsException, CorruptedMetadataException
    {
	this.firstAxisIndex = firstAxisIndex;
	init(mdata);
    }

    /**
     * create a GenCoordinateSystem with a particular value
     * @param mdata the set of metadata that describes the Coordinate system
     *              Note that expected metadata keys of the wrong type are 
     *              ignored (see above).
     */
    public GenCoordinateSystem(Metadata mdata) 
	throws ArrayIndexOutOfBoundsException, CorruptedMetadataException
    {
	this(mdata, 0);
    }

    private void init(Metadata mdata) {
	String sval, saval[], types[];
	Integer ival;
	CoordAxisPos[] capval;
	double[] rp, rv, vs;
	int i, al;

	// clone the input metadata; 
	// 
	defmdata = cloneMetadata(mdata);
	cmdata = new Metadata(defmdata);

	// check to be sure we have all the metadata we need.  Keep 
        // some extracted references to important information 
	// for even faster access (than from the hashtable cmdata)
	//
	// check for the number of axes: need at least 1
	//
	try {
	    ival = (Integer) cmdata.getMetadatum("naxes");
	} catch (ClassCastException e) {
	    ival = null;
	}
	if (ival == null) 
	    naxes = 0;
	else 
	    naxes = ival.intValue();
	if (naxes < 1) throw new 
	    ArrayIndexOutOfBoundsException("CoordinateSystem Metedatum naxes="
					   + naxes + " < 1");

	// Axis names & labels; need one for each axis (use "axnames" 
	// as default labels, if necessary).
	//
	String[] given, use;
	String[] skeys = { "axnames", "axlabels" };
	for(int j=0; j < skeys.length; j++) {
	    try {
		given = (String[]) defmdata.getMetadatum(skeys[j]);
	    } catch (ClassCastException ex) {
		throw new CorruptedMetadataException(skeys[j], 
						     "Unexpected type");
	    }
	    if (given == null || given.length < naxes) 
		use = new String[naxes];
	    else 
		use = given;

	    if (use != given) { 
		if (given != null) 
		    System.arraycopy(given, 0, use, 0, 
				     Math.min(given.length, naxes));
		defmdata.put(skeys[j], use);
	    }
	}

	// set the defaults
	given = (String[]) defmdata.getMetadatum("axnames");
	use   = (String[]) defmdata.getMetadatum("axlabels");
	for(i=0; i < naxes; i++) {
	    if (given[i] == null || given[i].length() == 0) 
		given[i] = new String("pixels");
	    if (use[i] == null || use[i].length() == 0) 
		use[i] = given[i];
	}
		

	// Axis value formatters; need one for each axis
	//
	CoordAxisPos[] got, employ;
	try {
	    got = (CoordAxisPos[]) defmdata.getMetadatum("axformats");
	} catch (ClassCastException ex) {
	    throw new CorruptedMetadataException("axlabels","Unexpected type");
	}
	if (got == null || got.length < naxes) 
	    employ = new CoordAxisPos[naxes];
	else 
	    employ = got;

	if (employ != got) {
	    if (got != null) {
		for(i=0; i < naxes && i < got.length; i++) 
		    employ[i] = got[i];
	    }
	    for(i=0; i < naxes; i++) {
		if (employ[i] == null) employ[i] = defPosPrinter;
	    }

	    defmdata.put(new String("axformats"), employ);
	}

	// system reference value, reference pixel, & pixel size
	double[] in, out;
	double[] deflt = { 0.0, 0.0, 1.0 };
	String[] keys = { "refposition", "refpixel", "pixelsize" };
	for(int j=0; j<3; j++) {
	    try {
		in = (double[]) defmdata.getMetadatum(keys[j]);
	    } catch (ClassCastException ex) {
	      throw new CorruptedMetadataException(keys[j], "Unexpected type");
	    }
	    if (in == null || in.length < naxes) 
		out = new double[naxes];
	    else
		out = in;

	    if (in != out) {
		i=0;
		if (in != null) {
		    for(; i < naxes && i < in.length; i++) out[i] = in[i];
		}
		for(; i < naxes; i++) out[i] = deflt[j];

		defmdata.put(keys[j], out);
	    }
	}
	try {
	    rp = (double[]) cmdata.getMetadatum("refposition");
	    rv = (double[]) cmdata.getMetadatum("refvoxel");
	    vs = (double[]) cmdata.getMetadatum("voxelsize");
	} catch (ClassCastException ex) {
	    throw new InternalError("Logic Error: corrupted metadata");
	}

	if (rp == null || rp.length < naxes) {
	    refposition = new double[naxes];
	    al = (rp == null) ? 0 : rp.length;
	    if (rp != null) System.arraycopy(rp, 0, refposition, 0, rp.length);
	    for(int j=al; j < refposition.length; j++) refposition[j] = 0;
	} 
	else { refposition = rp; }

	if (rv == null || rv.length < naxes) {
	    refvoxel = new double[naxes];
	    al = (rv == null) ? 0 : rv.length;
	    if (rv != null) System.arraycopy(rp, 0, refvoxel, 0, rv.length);
	    for(int j=al; j < refvoxel.length; j++) refvoxel[j] = 0;
	} 
	else { refvoxel = rv; }

	if (vs == null || vs.length < naxes) {
	    voxelsize = new double[naxes];
	    al = (vs == null) ? 0 : vs.length;
	    if (vs != null) System.arraycopy(rp, 0, voxelsize, 0, rp.length);
	    for(int j=al; j < voxelsize.length; j++) voxelsize[j] = 1;
	} 
	else { voxelsize = vs; }
    }

    /**
     * create a GenCoordinateSystem with a particular value.  This version of 
     * the  constructor is provided so that one does not have to completely
     * specify a metadatum list.  
     * @param nax the number of axes in this coordinate system
     * @param refval  value of the reference position along each axis
     * @param refvox  voxel location of the reference position
     * @param voxsz   size of a data voxel along each axis direction
     * @param aname[] an array of the axis names; these are used both as 
     *                labels and type names.
     * @param formatter[] an array of CoordAxisPos objects to use when 
     *               formatting the position into a string.
     * @param name an optional name to give for the overall system; a null
     *             argument causes no name to be set.
     * @param mdata  the metadatum list; if no other metadata need 
     *               specifying besides the above values, pass null for 
     *               this argument.
     * @param firstAxisIndex the initial value of firstAxisIndex, the default 
     *              index for the first axis.
     */
    public GenCoordinateSystem(int nax, double[] refval, double[] refvox, 
			 double[] voxsz, String[] aname, 
			 CoordAxisPos[] formatter, String name, 
			 Metadata mdata, int firstAxisIndex) 
	throws ArrayIndexOutOfBoundsException 
    {
	if (nax <= 0) throw new 
	    ArrayIndexOutOfBoundsException("CoordinateSystem property naxes=" 
					   + nax + " < 1");
	this.firstAxisIndex = firstAxisIndex;
	if (mdata == null) mdata = new Metadata();

	mdata.put(new String("naxes"), new Integer(nax));
	mdata.put(new String("axnames"), aname);
	mdata.put(new String("axlabels"), aname);
	mdata.put(new String("refposition"), refval);
	mdata.put(new String("refvoxel"), refvox);
	mdata.put(new String("voxelsize"), voxsz);
	if (name != null) mdata.put(new String("name"), name);
	if (formatter != null) mdata.put(new String("axformats"), formatter);

	init(mdata);
    }
	    
    /**
     * get coordinate position corresponding to a particular data voxel 
     * location
     * @param pos data location in the coordinate space (as an array of 
     *            doubles)
     * @param firstaxis the index at which the value for the first axis
     *                  appears in pos
     * @exception ArrayIndexOutOfBoundsException if firstaxis < 0
     */
    public CoordPos getCoordPos(double[] pos, int firstaxis) 
        throws ArrayIndexOutOfBoundsException
    {
	if (firstaxis < 0) throw new ArrayIndexOutOfBoundsException(firstaxis);
	double[] use;
	if (firstaxis > 0) {
	    use = new double[pos.length-firstaxis];
	    System.arraycopy(pos, firstaxis, use, 0, use.length);
	}
	else {
	    use = pos;
	}

	Metadata omdata = (Metadata) cmdata.clone();
	omdata.remove(new String("refposition"));
	omdata.remove(new String("refvoxel"));
	omdata.remove(new String("voxelsize"));

	return new GenCoordPos(getCoordVal(use, 0), omdata, firstAxisIndex);
    }

    /**
     * get coordinate position corresponding to a particular data
     * location <p>
     * Note to sub-classers: this actually calculates the position;
     * if one overrides this function, getCoordVal(), getCoordPos()
     * will effectively inherit the new behavior.
     * @param pos location in the coordinate space as a double[]
     * @param firstaxis the index at which the value for the first axis
     *           appears in pos and should appear in the returned array.
     */
    public double[] getCoordVal(double[] pos, int firstaxis) 
	throws ArrayIndexOutOfBoundsException
    {
	if (firstaxis < 0) throw new 
	    ArrayIndexOutOfBoundsException("firstaxis < 0: " + firstaxis);

	int i;
	double[] out = new double[naxes];
	for(i=0; i<naxes; i++) {
	    if (i + firstaxis < pos.length) {
		out[i] = refposition[i] + 
		           (pos[i+firstaxis] - refvoxel[i]) * voxelsize[i];
	    }
	    else {

		// if an axis position is not given; assume it is zero;
		out[i] = refposition[i] - refvoxel[i] * voxelsize[i];
	    }
	}

	return out;
    }

    /**
     * get the data voxel corresponding to the coordinate position given
     * by the input array.  
     * @param vals input coordinate values 
     * @param firstaxis the index at which the value for the first axis 
     *            appears in vals and should appear in the returned array.
     * @returns double[] coordinate position as an array of doubles
     */
    public double[] getVoxelVal(double[] vals, int firstaxis)
	throws ArrayIndexOutOfBoundsException 
    {
	if (firstaxis < 0) throw new 
	    ArrayIndexOutOfBoundsException("firstaxis < 0: " + firstaxis);

	int i;
	double[] out = new double[naxes];
	for(i=0; i<naxes; i++) {
	    if (i + firstaxis < vals.length) {
		out[i] = (vals[i+firstaxis] - refposition[i]) / voxelsize[i]
		           + refvoxel[i];
	    }
	    else {

		// if an axis position is not given; assume it is zero;
		out[i] = refvoxel[i] - refposition[i] / voxelsize[i];
	    }
	}

	return out;
    }

    /**
     * return a Metadata object that identifies this coordinate 
     * system.  
     */
    public Metadata getNativeMetadata() {
	return cloneMetadata(cmdata);
    }

    /**
     * return a Metadata object that identifies this coordinate 
     * system that positions will be converted to with calls to 
     * getCoordPos().  A Metadata list that matches the list
     * returned getInMetadata() does not guarantee that no
     * conversion is being done; to check if a conversion is being 
     * done, call willConvert();
     */
    public Metadata getConvertedMetadata() {
	if (converter == null) {
	    return getNativeMetadata();
	}
	else {
	    return converter.getConvertedMetadata(cmdata);
	}
    }

    /**
     * have positions returned with getCoordPos converted to another 
     * system using the given converter object.  Calling this method
     * will always update the labels returned by setAxisLabel().
     * @param cnv the converter object to use.  This Coord object will 
     *            be set for no conversion if cnv==null. 
     * @throws IncompatableCoordException 
     *                      thrown if the converter cannot be applied to 
     *                      this Coordinate system
     */
    public void setCoordConverter(CoordConverter cnv) 
 	throws IncompatableCoordException 
    {

	if (cnv == null) {

	    // remove the current converter
	    converter = null;
	    cmdata.removeAllMetadata();
	    return;
	}

	converter = (CoordConverter) cnv.clone();
	converter.init(this);

	// copy in the new metadata to override defaults
	Metadata newmdata = converter.getConvertedMetadata(defmdata);
        for (Enumeration e = newmdata.keys() ; e.hasMoreElements() ;) {
            String key = (String)e.nextElement();
            newmdata.put(key, newmdata.getMetadatum(key));
        }
    }

    /**
     * clone a Metadata object making "deep" copies of those metadata most
     * relevent to this object (and thus in need of protection), namely:
     * "naxes", "axnames", "axlabels", "axformats", "name", "refposition",
     * "refvoxel", & "voxelsize".  
     */
    protected static Metadata cloneMetadata(Metadata from) {
	Metadata out = (Metadata) from.clone();
	String[] instr, outstr;
	String ins, outs;
	CoordAxisPos[] incap, outcap;
	double[] ind, outd;
	Integer n;
	int i;

	// naxes
	try {                                     
	    n = (Integer) out.getMetadatum("naxes");
	} catch (ClassCastException e) {
	    n = null;
	}
	if (n != null) {
	    n = new Integer(n.intValue());
	    out.put(new String("naxes"), n);
	}

	// Data of type String[]: axis types, labels
	String[] skeys = { "axnames", "axlabels" };
	for (int j=0; j < 2; j++) {
	    try {                      
		instr = (String[]) out.getMetadatum(skeys[j]);
	    } catch (ClassCastException e) {
		instr = null;
	    }
	    if (instr != null) {
		outstr = new String[instr.length];
		System.arraycopy(instr, 0, outstr, 0, instr.length);
		out.put(new String(skeys[j]), outstr);
	    }
	}
	
	// Data of type CoordAxisPos[]: axis formatters
	try {                                      // get the axis labels
	    incap = (CoordAxisPos[]) out.getMetadatum("axformats");
	} catch (ClassCastException e) {
	    incap = null;
	}
	if (incap != null) {
	    outcap = new CoordAxisPos[incap.length];
	    System.arraycopy(incap, 0, outcap, 0, incap.length);
	    out.put(new String("axformats"), outcap);
	}

	// Data of type String:  coordinate system name:
	try {                                      // get the axis labels
	    ins = (String) out.getMetadatum("name");
	} catch (ClassCastException e) {
	    ins = null;
	}
	if (ins != null) {
	    outs = ins.substring(0);
	    out.put(new String("name"), outs);
	}

	// Data of type double[]:  system reference value, reference 
	// voxel, & voxel size
	String[] dkeys = { "refposition", "refvoxel", "voxelsize" };
	for (int j=0; j<3; j++) {
	    try {
		ind = (double[]) out.getMetadatum(dkeys[j]);
	    } catch (ClassCastException ex) {
	      throw new CorruptedMetadataException(dkeys[j],"Unexpected type");
	    }
	    if (ind != null) {
		outd = new double[ind.length];
		System.arraycopy(ind, 0, outd, 0, ind.length);
		out.put(new String(dkeys[j]), outd);
	    }
	}

	return out;
    }	



    /**
     * return the number of axes in the space containing this position
     */
    public int getNaxes() { return naxes; }

    /**
     * return the name of an axis
     * @param axis the axis of interest; axes are numbered beginning with 0.
     */
    public String axisLabel(int axis) 
	throws ArrayIndexOutOfBoundsException
    {
	String[] labels = axisLabels();

	if (labels == null) 
	    return new String();
	else
	    return labels[axis-firstAxisIndex];
    }

    /**
     * return the axis labels as an array of strings
     * @param firstaxis the index at which the label of the first axis 
     *                  should appear in the returned array
     * @exceptions ArrayIndexOutOfBoundsException if firstaxis < 0
     */
    public String[] axisLabels(int firstaxis) {
	if (firstaxis < 0) throw new 
	    ArrayIndexOutOfBoundsException("firstaxis < 0: " + firstaxis);

	String[] labels;

	try {
	    labels = (String[]) cmdata.getMetadatum("axlabels");
	} catch (ClassCastException ex) {
	    throw new CorruptedMetadataException("axlabels","Unexpected type");
	}
	if (labels == null) return null;

	String[] out = new String[labels.length+firstaxis];
	System.arraycopy(labels, 0, out, firstaxis, labels.length);
	return out;
    }
	
    /**
     * set the label for an axis
     * @param lab label to use
     * @param axis the axis of interest; axes are numbered beginning with 0.
     */
    public void setAxisLabel(String lab, int axis) 
	throws ArrayIndexOutOfBoundsException 
    {
	String[] labels;
	Metadata use;

	if (lab == null) return;

	if (converter == null) 
	    use = cmdata;
	else
	    use = defmdata;

	try {
	    labels = (String[]) use.getMetadatum("axlabels");
	} catch (ClassCastException ex) {
	    throw new CorruptedMetadataException("axlabels","Unexpected type");
	}
	if (labels == null) 
	    throw new CorruptedMetadataException("axlabels", "Null value");

	labels[axis-firstAxisIndex] = lab;
    }

    /**
     * set the labels for all the axes
     * @param lab label to use
     * @param axis the axis of interest; axes are numbered beginning with 0.
     */
    public void setAxisLabels(String[] lab, int firstaxis) {
	if (firstaxis < 0) throw new 
	    ArrayIndexOutOfBoundsException("firstaxis < 0: " + firstaxis);

	int i;
	Metadata use;
	String[] labels;

	if (lab == null) return;

	if (converter == null) 
	    use = cmdata;
	else
	    use = defmdata;

	try {
	    labels = (String[]) use.getMetadatum("axlabels");
	} catch (ClassCastException ex) {
	    throw new CorruptedMetadataException("axlabels","Unexpected type");
	}
	for(i=0; i + firstaxis < lab.length && i < labels.length; i++) 
	    labels[i] = lab[i+firstaxis];
    }

    public static void main(String args[]) {

	String sp;
	int i;
	String names[] = { "RA", "Dec", "Velo" };
	double[] refvox = { 45.7, 23.0, 18.0 },
		 refpos = { 120.0, 30.0, 100.0 },
		 voxsz  = { 1/3600.0, 1/3600.0, 5.0 },
		 origin = { 0.0, 0.0, 0.0 };
	CoordAxisPos frmtrs[] = { new HHMMSSCoordAxisPos(),
				  new DDMMSSCoordAxisPos(),
				  new GenericCoordAxisPos() };
	Metadata mdata = new Metadata();
	mdata.put(new String("space"), new String("Celestial-Velocity"));

	CoordinateSystem space = 
	    new GenCoordinateSystem(3, refpos, refvox, voxsz, names,
				    frmtrs, null, mdata, 0);

	CoordPos mycp = space.getCoordPos(origin);
	sp = (String) mycp.getMetadata().getMetadatum(new String("space"), 
			    	                      new String("my"));
	System.out.println("My position in " + sp + " space...");
	for (i=0; i < mycp.getNaxes(); i++) {
	    System.out.println("  " + mycp.axisLabel(i) + 
			       ": " + mycp.valStr(i)      );
	}
	if (args.length <= 0) System.exit(0);

	double[] yours = new double[args.length];
	for(i=0; i < args.length; i++) {
	    yours[i] = new Double(args[i]).doubleValue();
	}

	CoordPos yourcp = space.getCoordPos(yours);
	System.out.println("Your position " + sp + " space...");
	for (i=0; i < yourcp.getNaxes(); i++) {
	    System.out.println("  " + yourcp.axisLabel(i) + 
			       ": " + yourcp.valStr(i)      );
	}
    }

}


