/*
 * NCSA Horizon Image Browser
 * Project Horizon
 * National Center for Supercomputing Applications
 * University of Illinois at Urbana-Champaign
 * 605 E. Springfield, Champaign IL 61820
 * horizon@ncsa.uiuc.edu
 *
 * Copyright (C) 1996, Board of Trustees of the University of Illinois
 *
 * NCSA Horizon software, both binary and source (hereafter, Software) is
 * copyrighted by The Board of Trustees of the University of Illinois
 * (UI), and ownership remains with the UI.
 *
 * You should have received a full statement of copyright and
 * conditions for use with this package; if not, a copy may be
 * obtained from the above address.  Please see this statement
 * for more details.
 *
 */
/**
 * @version 1.0
 * @author Raymond L. Plante
 */

package ncsa.horizon.coordinates;

import ncsa.horizon.util.Voxel;
import ncsa.horizon.util.Metadata;
import java.util.*;

/**
 * a description of a world coordinate system and the mapping between 
 * it and a multidimensional gridded dataset. <p>
 *
 * A CoordinateSystem object can be given a data voxel location and return
 * a position in its world coordinate space in the form of a CoordPos
 * object.  The code might look something like this:
 * <pre>
 *    CoordinateSystem wcs;
 *    CoordPos wcspos;
 *    ...
 *    double datapos[] = { 0, 0, 0 };   // coordinate origin
 *    wcs.firstAxisIndex = 0;     // set how we will number the axes
 *    wcspos = wcs.getCoordPos(datapos);
 *    System.out.println( wcspos.axisLabel(0) +   // print position
 *                        ": " +                  //  along 1st axis
 *                        wcspos.valStr(0) );     
 *    System.out.println( wcspos.axisLabel(1) +   // print position
 *                        ": " +                  //  along 2nd axis
 *                        wcspos.valStr(1) );     
 * </pre>
 * which might produce something the following:
 * <pre>
 *    RA: 12:45:39.11
 *    Dec: -30:17:20.2
 * </pre>
 *
 * The getVoxelVal() and getVoxel() do the opposite transform of 
 * getCoordPos(), translating a coordinate positions into voxel locations 
 * in the dataset. <p>
 *
 * A Coordinate object can automatically convert positions to other
 * coordinate systems by attaching a CoordConverter object to it with 
 * setCoordOut(); all subsequent calls to getCoordPos will produce 
 * positions in the new coordinate system. <p>
 *
 * Most users will only make use of the getCoordPos() method and possibly 
 * the setCoordConverter() method.  Implementers of this class and of 
 * CoordPos and CoordConverter classes should will need to understand the 
 * role of Metadata objects in these classes as described below. <p>
 *
 * <b> CoordinateSystem Metadata </b><p>
 *
 * CoordinateSystem and CoordPos objects maintain internal Metadata objects
 * that hold named data describing the coordinate system and are usually
 * set when the Coordinate or CoordPos object is instantiated.  The
 * Metadata object can contain any data (of any type) relevent to the 
 * particular system; however, certain data specifically related to all
 * coordinate systems are expected to be of a certain type:
 *
 * <pre>
 *   <b>Key name</b>       <b>Type</b>             <b>Description</b> 
 *  *naxes          Integer          number of axes
 *   axnames        String[]         names identifying each axis
 *   axlabels       String[]         labels for each axis 
 *                                   (when printing positions)
 *   axformats      CoordAxisPos[]   position formatting objects for each
 *                                   axis (when printing positions)
 *   name           String           Arbitrary name for system
 * <br>
 *  *must be specified for all Coordinate and CoordPos objects.
 * </pre>
 *
 * Specific instantiations of Coordinate and CoordPos objects may expect
 * other metadata of specific types.  In general however, when the 
 * metadata are needed but not specified, sensible defaults are used, 
 * except for "naxes" which must always be set (> 0) or an 
 * ArrayIndexOutOfBoundsException may be thrown. <p>
 *
 * <b> Axis Numbering Convention </b><p>
 *
 * The axis numbering convention can be set via the public field 
 * firstAxisIndex.  One usually sets this to either 0 or 1, but it can be 
 * set to any integer.  (A firstAxisIndex<0 is a good way to confuse oneself.)
 * The value of firstAxisIndex has the following effect: 
 * <ul>
 *   <li> the index argument given to axisLabel(int) is taken to be relative 
 *        to the value of firstAxisIndex.  
 *   <li> The firstAxisIndex field of CoordPos objects returned by the
 *        getCoordPos() methods will be set to the same value.
 *   <li> values for the first axis in arrays returned axisLabels() will 
 *        appear an index of firstAxisIndex, unless firstAxisIndex<0.
 * </ul> 
 * Note that the value of firstAxisIndex should not affect how internal 
 * data is stored. <p>
 *
 * If it possible that other threads may be accessing this CoordinateSystem 
 * object at the same time, synchronized access to this object is recommended; 
 * e.g: 
 * <pre>
 *    CoordinateSystem wcs;
 *    double[] data;
 *    ...
 *    synchronized (wcs) {
 *        wcs.firstAxisIndex = 1;
 *        CoordPos wcspos = wcs.getCoordPos(data);
 *    }
 * </pre><p>
 *
 * The safest practice is to set the firstAxisIndex during construction and 
 * stick with that convention.  Horizon objects that return CoordinateSystem 
 * objects (e.g. Horizon implementations of the Viewable interface) use 
 * firstAxisIndex=0.
 */
public abstract class CoordinateSystem {

    /**
     * default index of the first axis.  For example, the index argument
     * given to axisLabel(int) should be relative to the value of 
     * firstAxisIndex.  Also, the firstAxisIndex field of the CoordPos 
     * objects returned by getCoordPos will be set to this value.
     */
    public int firstAxisIndex=0;

    /**
     * current converter object being used with this CoordinateSystem object
     */
    protected CoordConverter converter=null;

    /**
     * get coordinate position corresponding to a particular voxel 
     * location
     * @param pos a double array containing the coordinate position
     * @param firstaxis index of the value in pos for the first axis
     * @exception ArrayIndexOutOfBoundsException if firstaxis < 0
     */
    public abstract CoordPos getCoordPos(double[] pos, int firstaxis)
        throws ArrayIndexOutOfBoundsException;

    /**
     * get coordinate position corresponding to a particular voxel 
     * location
     * @param pos a double array containing the coordinate position;
     *            the first element (index 0) is the positions along 
     *            the first axis.
     */
    public CoordPos getCoordPos(double[] pos) {
	return getCoordPos(pos, 0);
    }

    /**
     * get coordinate position corresponding to a particular voxel 
     * location
     * @param Voxel location in the coordinate space
     */
    public CoordPos getCoordPos(Voxel vox) {
	return getCoordPos(vox.getValues(0), 0);
    }

    /**
     * get coordinate position corresponding to a particular voxel 
     * location
     * @param Voxel location in the coordinate space
     */
    public double[] getCoordVal(Voxel vox) {
	return getCoordVal(vox.getValues(0));
    }

    /**
     * get coordinate position corresponding to a particular voxel 
     * location
     * @param pos location in the coordinate space as a double array
     * @param firstaxis the index at which the value for the first axis 
     *            appears in pos and should appear in the returned array.
     * @exceptions ArrayIndexOutOfBoundsException if firstaxis < 0
     */
    public abstract double[] getCoordVal(double[] pos, int firstaxis)
	throws ArrayIndexOutOfBoundsException;

    /**
     * get coordinate position corresponding to a particular voxel 
     * location
     * @param pos location in the coordinate space as a double array
     */
    public double[] getCoordVal(double[] pos) {
	return ((firstAxisIndex < 0) ? getCoordVal(pos, 0) : 
		                       getCoordVal(pos, firstAxisIndex));
    }

    /**
     * get the data voxel corresponding to the coordinate position given
     * by the input array.  
     * @param vals input coordinate values 
     * @param firstaxis the index at which the value for the first axis 
     *            appears in vals and should appear in the returned array.
     * @returns double[] coordinate position as an array of doubles
     * @exception ArrayIndexOutOfBoundsException if firstaxis < 0;
     */
    public abstract double[] getVoxelVal(double[] vals, int firstaxis)
	throws ArrayIndexOutOfBoundsException;

    /**
     * get the data voxel corresponding to the coordinate position given
     * by the input array.  
     * @param vals input coordinate values 
     * @returns double[] coordinate position as an array of doubles; the
     *            index of the value for the first axis will be 
     *            firstAxisIndex or zero, which ever is larger.
     */
    public double[] getVoxelVal(double[] vals) {
	return ((firstAxisIndex < 0) ? getVoxelVal(vals, 0) : 
		                       getVoxelVal(vals, firstAxisIndex));
    }

    /**
     * get the data voxel corresponding to the coordinate position given
     * by the input array.  
     * @param cp the input coordinate position
     * @param firstaxis the index at which the value for the first axis 
     *            appears in pos and should appear in the returned array.
     * @returns double[] data voxel as an array of doubles
     * @exception ArrayIndexOutOfBoundsException if firstaxis < 0;
     */
    public double[] getVoxelVal(CoordPos cp, int firstaxis)
	throws ArrayIndexOutOfBoundsException
    {
	if (firstaxis < 0) throw new ArrayIndexOutOfBoundsException(
	    "Requested first axis index < 0: " + firstaxis);
	return getVoxelVal(cp.values(firstaxis));
    }

    /**
     * get the data voxel corresponding to the coordinate position given
     * by the input array.  
     * @param cp the input coordinate position
     * @returns double[] coordinate position as an array of doubles; the
     *            index of the value for the first axis will be 
     *            firstAxisIndex or zero, which ever is larger.
     */
    public double[] getVoxelVal(CoordPos cp) {
      return getVoxelVal(cp.values((firstAxisIndex < 0) ? 0 : firstAxisIndex));
    }

    /**
     * get the data voxel corresponding to the coordinate position given
     * by the input array.  
     * @param cp the input coordinate position
     * @returns Voxel the data voxel
     */
    public Voxel getVoxel(CoordPos cp) {
	Voxel out = new Voxel(cp.getNaxes(), firstAxisIndex);
	out.setValues(cp.values(0), 0);
	return out;
    }

    /**
     * have positions returned with getCoordPos converted to another 
     * system using the given converter object.  Calling this method
     * will always update the labels returned by setAxisLabel().
     * @param cnv the converter object to use.  This Coord object will 
     *            be set for no conversion if cnv==null. 
     * @throws IncompatableCoordException 
     *                      thrown if the converter cannot be applied to 
     *                      this Coordinate system
     */
    public abstract void setCoordConverter(CoordConverter cnv) 
 	throws IncompatableCoordException;

    /**
     * returns true if a CoordConverter has been set.
     */
    public boolean willConvert() { return (converter == null); }

    /**
     * get the converter object used to change to the output 
     * coordinate system.  null will be returned if no conversion is set 
     * to be done, but it is better to use willConvert() to test this case.
     */
    public CoordConverter getConverter() {
	if (converter == null) 
	    return null;
	else 
	    return (CoordConverter) converter.clone();
    }
    
    /**
     * return a Metadata object that identifies this coordinate 
     * system.  
     */
    public abstract Metadata getNativeMetadata();

    /**
     * return a Metadata object that identifies this coordinate 
     * system that positions will be converted to with calls to 
     * getCoordPos().  A Metadata list that matches the list
     * returned getInMetadata() does not guarantee that no
     * conversion is being done; to check if a conversion is being 
     * done, call willConvert();
     */
    public abstract Metadata getConvertedMetadata();

    /**
     * return the number of axes in the space containing this position
     */
    public abstract int getNaxes();

    /**
     * return the name of an axis
     * @param axis the axis of interest; axes are numbered beginning 
     *             with the current value of firstAxisIndex
     */
    public abstract String axisLabel(int axis) 
	throws ArrayIndexOutOfBoundsException;

    /**
     * return the axis labels as an array of strings
     * @param firstaxis the index at which the label of the first axis 
     *                  should appear in the returned array
     * @exceptions ArrayIndexOutOfBoundsException if firstaxis < 0
     */
    public abstract String[] axisLabels(int firstaxis);

    /**
     * return the axis labels as an array of strings.  The index of the 
     * label for the first axis will be the the larger of firstAxisIndex 
     * and zero.
     */
    public String[] axisLabels() { 
	return (firstAxisIndex < 0) ? axisLabels(0) : 
	                              axisLabels(firstAxisIndex); 
    }

    /**
     * set the label for an axis
     * @param axis the axis of interest. Axes are numbered using the 
     *             convention specified by firstAxisIndex
     */
    public abstract void setAxisLabel(String lab, int axis)
	throws ArrayIndexOutOfBoundsException;

    /**
     * set all the labels for all the axes
     * @param labs the labels to be used
     * @param firstaxis the index of the label of the first axis in labs
     * @exception ArrayIndexOutOfBoundsException if firstaxis < 0;
     */
    public abstract void setAxisLabels(String[] labs, int firstaxis)
	throws ArrayIndexOutOfBoundsException;

    /**
     * set all the labels for all the axes
     * @param labs the labels to be used.  The index of the label of the 
     *             first axis will be the larger of firstAxisIndex and zero.
     */
    public void setAxisLabels(String[] labs) {
	if (firstAxisIndex < 0)
	    setAxisLabels(labs, 0);
	else
	    setAxisLabels(labs, firstAxisIndex);
    }
};

