/*
 * NCSA Horizon Image Browser
 * Project Horizon
 * National Center for Supercomputing Applications
 * University of Illinois at Urbana-Champaign
 * 605 E. Springfield, Champaign IL 61820
 * horizon@ncsa.uiuc.edu
 *
 * Copyright (C) 1996, Board of Trustees of the University of Illinois
 *
 * NCSA Horizon software, both binary and source (hereafter, Software) is
 * copyrighted by The Board of Trustees of the University of Illinois
 * (UI), and ownership remains with the UI.
 *
 * You should have received a full statement of copyright and
 * conditions for use with this package; if not, a copy may be
 * obtained from the above address.  Please see this statement
 * for more details.
 *
 */
package ncsa.horizon.coordinates;

import java.util.*;
import ncsa.horizon.util.Metadata;

/**
 * support for converting a position from one coordinate system to another
 */
public abstract class CoordConverter implements Cloneable {

    protected boolean convertible=false;
    protected CoordinateSystem client=null;

    /**
     * convert the position from the native system to the converted system
     */
    public abstract CoordPos forwardConvert(CoordPos pos) 
	throws IncompatableCoordException;

    /**
     * convert the position from the converted system back to the native 
     * system
     */
    public abstract CoordPos reverseConvert(CoordPos pos) 
	throws IncompatableCoordException;

    /**
     * return an object containing the metadata that must be present 
     * in the coordinate system it is applied to for proper use of 
     * this converter.  Note: To prove that this converter is compatible 
     * with a particular Coordinate system, use canConvert().
     */
    public abstract Metadata getNativeMetadata();

    /**
     * determine if this converter can covert from a coordinate system
     * having the given metadata.
     */
    public abstract boolean canConvert(Metadata from);

    /**
     * determine if this converter can convert from a given coordinate 
     * system.
     */
    public boolean canConvert(CoordinateSystem sys) {
	return canConvert(sys.getNativeMetadata());
    }

    /**
     * return the metadata describes the conversion.
     */
    public abstract Metadata getConvertedMetadata();

    /**
     * return the metadata for a converted position assuming the
     * unconverted position has a given metadatum list.
     */
    public abstract Metadata getConvertedMetadata(Metadata in);

    /**
     * return a copy of this converter object.
     */
    public abstract Object clone();

    /**
     * a routine to be run by a CoordinateSystem object when this converter 
     * is attached to it.  (It is not a good idea to call this at other 
     * times.)  The CoordinateSystem object passes its <code>this</code>
     * pointer to this method.
     *
     * Users that wish override this method should call super.init(); 
     * this sets the boolean flag, <code>convertible</code>, indicating 
     * that this converter is compatible with the CoordinateSystem system it 
     * is attached to.  Generally, this method does some pre-computing
     * in order to make subsequent conversions faster. 
     */
    public void init(CoordinateSystem caller) 
	throws IncompatableCoordException 
    { 
	convertible = canConvert(caller.getNativeMetadata()); 
	if (! convertible) 
	    throw new IncompatableCoordException("Unable to convert from " +  
						 "given coordinate system ");
	client = caller;
    }

    /**
     * extract the String array of axis names from the metadatum list 
     * (i.e. the "axnames" metadatum); null is returned if not found
     * (or is of the wrong type).
     */
    public static String[] getAxisNames(Metadata in) {
	try {
	    return (String[]) in.getMetadatum("axnames");
	}
	catch (ClassCastException e) { 
	    return null;
	}
    }

    /**
     * return the keys in the input Metadata (as an array of
     * Strings) whose values match a particular value.
     * @param in       input Metadata list to search
     * @param toffset  begin search of Metadatum value at position toffset 
     * @param value    metadatum value to compare to
     * @param ooffset  compare to substring of value starting at position 
     *                 ooffset
     * @param len      use first len characters in comparison.  If len=0, 
     *                 compare first value.length() characters; if len<0,
     *                 look for an exact match (of substrings using toffset
     *                 and ooffset).
     * @returns an Integer array containing the key names, or null if 
     *          none were found.
     */
    public static Integer[] matchingAxis(Metadata in, int toffset, 
				 	 String value, int ooffset, int len) {

	String[] types;
	int i, j;
	Integer[] out;
	Vector matches = new Vector();

	types = getAxisNames(in);
	if (types == null) return null;

	for(i=0; i < types.length; i++) {
	    if (len <= 0) {
		if (types[i].equals(value)) 
		    matches.addElement(new Integer(i));
	    }
	    else {
		if (types[i].regionMatches(toffset, value, ooffset, len)) 
		    matches.addElement(new Integer(i));
	    }
	}

	// copy the Vector of matches to an int array 
	j = matches.size();
	if (j == 0) return null;
	out = new Integer[j];
	for(i=0; i < j; i++) {
	    out[i] = (Integer) matches.elementAt(i);
	}

	return out;
    }
	
    /**
     * same as int[] matchingAxis(in, 0, value, 0, len)
     */
    public static Integer[] matchingAxis(Metadata in, String value, int len) {
	return matchingAxis(in, 0, value, 0, len);
    }

    /** 
     * return axis key from input Metadata with value exactly matching 
     * input value.  This is the like
     * <code>(String matchingAxis(in, 0, value, 0, -1))[0]</code>
     * (assuming matchingAxis did not return null).
     */
    public static Integer exactMatchingAxis(Metadata in, String value) {
	Integer[] tmp = matchingAxis(in, 0, value, 0, -1);
	return ( (tmp == null) ? null : tmp[0] );
    }

    /**
     * return axis key with the smallest index from the input Metadata 
     * with a value matching the input value.
     * @param in       input Metadata list to search
     * @param toffset  begin search of Metadatum value at position toffset 
     * @param value    metadatum value to compare to
     * @param ooffset  compare to substring of value starting at position 
     *                 ooffset
     * @param len      use first len characters in comparison.  If len=0, 
     *                 compare first value.length() characters; if len<0,
     *                 look for an exact match (of substrings using toffset
     *                 and ooffset).
     * @returns an Integer containing the index of the axis, or null if a 
     *          was not found.
     */
    public static Integer firstMatchingAxis(Metadata in, int toffset, 
					   String value, int ooffset, int len) 
    {
	Integer[] list = matchingAxis(in, toffset, value, ooffset, len);
	int i, j, min=Integer.MAX_VALUE, min_idx=list.length;

	if (list == null || list.length == 0) return null;

	for(i=0; i < list.length; i++) {

	    j = list[i].intValue();
	    if (j < min) { 
		min = j;
		min_idx = i;
	    }
	    if (min == 0) break;
	}

	if (min_idx == list.length) 
	    return null;
	else 
	    return list[min_idx];
    }

    /**
     * same as String firstMatchingAxis(in, 0, value, 0, 0)
     */
    public static Integer firstMatchingAxis(Metadata in, String value) {
	return firstMatchingAxis(in, 0, value, 0, 0);
    }

}

/* check on */
